// Named, pure resolver functions: (model, ...args, ctx) -> printable value.
// Mappings reference them by name: { "field": "abil_str_mod", "resolver": "abilityMod", "args": ["str"] }
// or by model path: { "field": "char_name", "value": "identity.name" }.

import { num, signed, joinNonEmpty, dice } from "../model/text.mjs";
import { terms } from "../model/terms.mjs";

const get = (obj, path) => String(path).split(".").reduce((o, k) => (o === null || o === undefined ? undefined : o[k]), obj);
const nz = (v) => (v === 0 || v === "0" ? "" : v);            // print empty instead of 0
const ifNum = (v) => (v === null || v === undefined || Number.isNaN(Number(v)) ? "" : String(v));

export const RESOLVERS = {
  // ----- generic -----
  path: (m, path) => get(m, path) ?? "",
  const: (m, value) => value,
  join: (m, path, sep = ", ") => (get(m, path) ?? []).join(sep),
  number: (m, path, ctx) => num(get(m, path), ctx.lang),
  numberOrEmpty: (m, path, ctx) => nz(num(get(m, path), ctx.lang)),
  signed: (m, path) => signed(get(m, path)),

  // ----- identity -----
  classLabel: (m) => m.identity.classShort,
  classWithSubclass: (m) => m.identity.classLabel,
  xp: (m, ctx) => (m.identity.xp.value ? num(m.identity.xp.value, ctx.lang, 0) : ""),

  // ----- abilities, saves, skills -----
  abilityScore: (m, k) => ifNum(m.abilities[k]?.score),
  abilityMod: (m, k) => m.abilities[k]?.modLabel ?? "",
  saveBonus: (m, k) => m.abilities[k]?.saveLabel ?? "",
  saveProf: (m, k) => !!m.abilities[k]?.saveProf,
  skillBonus: (m, k) => m.skills[k]?.totalLabel ?? "",
  skillProf: (m, k) => (m.skills[k]?.prof ?? 0) >= 1,
  skillExpert: (m, k) => (m.skills[k]?.prof ?? 0) >= 2,
  skillHalf: (m, k) => (m.skills[k]?.prof ?? 0) === 0.5,
  passive: (m, k) => ifNum(m.skills[k]?.passive),

  // ----- combat -----
  ac: (m) => ifNum(m.combat.ac),
  initiative: (m) => m.combat.initiativeLabel,
  speed: (m) => m.combat.speed,
  speedFull: (m) => joinNonEmpty([m.combat.speed, m.combat.speedsLabel], "; "),
  profBonus: (m) => m.combat.profLabel,
  inspiration: (m) => !!m.combat.inspiration,
  hp: (m, which) => (which === "temp" || which === "tempmax" ? nz(ifNum(m.combat.hp[which])) : ifNum(m.combat.hp[which])),
  hitDiceTotal: (m) => m.combat.hitDiceLabel,
  hitDiceRemaining: (m) => (m.combat.hitDice.length > 1 ? m.combat.hitDiceRemainingLabel : ifNum(m.combat.hitDiceRemaining)),
  deathSuccess: (m, i) => m.combat.deathSaves.success >= i,
  deathFailure: (m, i) => m.combat.deathSaves.failure >= i,
  exhaustion: (m, i) => m.combat.exhaustion >= i,
  senses: (m) => m.sensesLabel,
  defenses: (m, ctx) => {
    const L = ctx.mapping.labels ?? {};
    const d = m.defenses;
    return joinNonEmpty([
      d.resistances.length ? `${L.resistances ?? "Resistenz"}: ${d.resistances.join(", ")}` : "",
      d.immunities.length ? `${L.immunities ?? "Immunität"}: ${d.immunities.join(", ")}` : "",
      d.vulnerabilities.length ? `${L.vulnerabilities ?? "Anfälligkeit"}: ${d.vulnerabilities.join(", ")}` : "",
      d.conditionImmunities.length ? `${L.conditionImmunities ?? "Zustandsimmunität"}: ${d.conditionImmunities.join(", ")}` : "",
    ], "; ");
  },
  conditions: (m) => m.combat.conditions.join(", "),

  // ----- proficiencies -----
  armorProf: (m, key) => {
    const T = terms(m.meta.lang).armorProf;
    return m.proficiencies.armor.includes(T[key]);
  },
  weaponProf: (m, key) => {
    const T = terms(m.meta.lang).weaponProf;
    return m.proficiencies.weapons.includes(T[key]);
  },
  weaponsOther: (m) => {
    const T = terms(m.meta.lang).weaponProf;
    const cats = new Set(Object.values(T));
    return m.proficiencies.weapons.filter((w) => !cats.has(w)).join(", ");
  },
  armorAndWeapons: (m) => joinNonEmpty([m.proficiencies.armorLabel, m.proficiencies.weaponsLabel], "; "),
  tools: (m) => m.proficiencies.tools.map((t) => (t.prof >= 2 ? `${t.label} (${terms(m.meta.lang).words.expertise})` : t.label)).join(", "),
  languages: (m) => m.proficiencies.languagesLabel,
  proficienciesAndLanguages: (m, ctx) => {
    const L = ctx.mapping.labels ?? {};
    return joinNonEmpty([
      m.proficiencies.armorLabel && `${L.armor ?? "Rüstung"}: ${m.proficiencies.armorLabel}`,
      m.proficiencies.weaponsLabel && `${L.weapons ?? "Waffen"}: ${m.proficiencies.weaponsLabel}`,
      m.proficiencies.toolsLabel && `${L.tools ?? "Werkzeuge"}: ${m.proficiencies.toolsLabel}`,
      m.proficiencies.languagesLabel && `${L.languages ?? "Sprachen"}: ${m.proficiencies.languagesLabel}`,
    ], "\n");
  },

  // ----- features -----
  /** Features of given categories as "Name: summary" paragraphs (full text goes to appendix on overflow). */
  featuresText: (m, categories, mode = "summary") => {
    const cats = Array.isArray(categories) ? categories : [categories];
    return m.features
      .filter((f) => cats.includes(f.category) || (cats.includes("other") && !["class", "race", "background", "feat"].includes(f.category)))
      .map((f) => {
        const uses = f.uses ? ` (${f.uses.max}× ${f.uses.recovery})`.replace(" ()", "") : "";
        const body = mode === "names" ? "" : mode === "full" ? f.description : f.summary;
        return body ? `${f.name}${uses}: ${body}` : `${f.name}${uses}`;
      })
      .join(mode === "full" ? "\n\n" : "\n");
  },

  /** Attacks beyond the first `skip` rows as text lines (for sheets with few attack rows + a free text box). */
  attacksText: (m, skip = 0) => m.attacks.slice(skip)
    .map((a) => `${a.name}: ${joinNonEmpty([a.toHit, a.damageLabel, a.range ? `(${a.range})` : ""], " ")}`)
    .join("\n"),

  // ----- equipment -----
  coin: (m, k) => nz(String(m.equipment.currency[k] ?? "")),
  totalGold: (m, ctx) => (m.equipment.totalGold ? num(m.equipment.totalGold, ctx.lang, 2) : ""),
  attuned: (m, i) => m.equipment.items.filter((x) => x.attuned)[i - 1]?.name ?? "",
  encumbrance: (m) => m.equipment.encumbrance.valueLabel,
  carryCapacity: (m) => m.equipment.encumbrance.maxLabel,
  equipmentText: (m) => m.equipment.items.map((i) => `${"  ".repeat(i.depth)}${i.quantity > 1 ? `${i.quantity}× ` : ""}${i.name}`).join("\n"),

  // ----- spellcasting -----
  spellClass: (m) => m.spellcasting.classLabel,
  spellAbility: (m) => m.spellcasting.abilityAbbr,
  spellAbilityFull: (m) => m.spellcasting.abilityLabel,
  spellDc: (m) => (m.spellcasting.hasSpells ? ifNum(m.spellcasting.dc) : ""),
  spellAttack: (m) => (m.spellcasting.hasSpells ? m.spellcasting.attackLabel : ""),
  spellPreparedMax: (m) => ifNum(m.spellcasting.preparedMax),
  slotMax: (m, lvl) => ifNum(m.spellcasting.slots.find((s) => s.level === lvl)?.max),
  slotUsed: (m, lvl, i) => {
    const s = m.spellcasting.slots.find((x) => x.level === lvl);
    return !!s && (s.max - s.value) >= i;
  },
  slotUsedCount: (m, lvl) => {
    const s = m.spellcasting.slots.find((x) => x.level === lvl);
    return s && s.max - s.value > 0 ? String(s.max - s.value) : "";
  },
  slotAvailable: (m, lvl, i) => {
    const s = m.spellcasting.slots.find((x) => x.level === lvl);
    return !!s && s.value >= i;
  },
  pactLevel: (m) => (m.spellcasting.pact ? String(m.spellcasting.pact.level) : ""),
  pactMax: (m) => (m.spellcasting.pact ? String(m.spellcasting.pact.max) : ""),
  pactUsed: (m, i) => !!m.spellcasting.pact && (m.spellcasting.pact.max - m.spellcasting.pact.value) >= i,
  cantripsText: (m) => m.spellcasting.byLevel[0].map((s) => s.name).join(", "),
  spellNamesByLevel: (m, lvl) => m.spellcasting.byLevel[lvl].map((s) => s.name).join(", "),

  /** Spells with costly or consumed material components ("Zaubernotizen"). */
  spellMaterials: (m) => m.spellcasting.spells
    .filter((s) => s.components.material && (s.components.cost > 0 || s.components.consumed))
    .map((s) => `${s.name}: ${s.components.materials}${s.components.consumed ? ` (${terms(m.meta.lang).words.consumed})` : ""}`)
    .join("\n"),

  // ----- identity helpers -----
  /** Single class: its name; multiclass: "Kämpfer 3 / Magier 2". */
  classNameOrMulti: (m) => (m.identity.classes.length > 1 ? m.identity.classShort : (m.identity.classes[0]?.name ?? "")),

  /** Features usable in combat (action/bonus/reaction or limited uses), compact. */
  combatFeatures: (m) => m.features
    .filter((f) => f.activation || f.uses)
    .map((f) => {
      const meta = joinNonEmpty([f.activation, f.uses ? `${f.uses.max}× ${f.uses.recovery}`.trim() : ""], ", ");
      const text = f.summary.length > 140 ? `${f.summary.slice(0, 137).replace(/\s+\S*$/, "")} …` : f.summary;
      return `${f.name}${meta ? ` (${meta})` : ""}${text ? `: ${text}` : ""}`;
    })
    .join("\n"),

  /** Magic items and valuables ("Schätze & Besonderes"). */
  treasure: (m) => m.equipment.items
    .filter((i) => i.magical || (i.type === "loot" && i.rarity))
    .map((i) => `${i.quantity > 1 ? `${i.quantity}× ` : ""}${i.name}${i.attuned ? ` (${terms(m.meta.lang).words.attuned})` : ""}`)
    .join("\n"),

  // ----- persona -----
  persona: (m, k) => m.persona[k] ?? "",
  size: (m) => m.identity.size,
};

// ---------------------------------------------------------------------------
// List resolvers: return arrays of row objects whose keys match mapping columns.
// ---------------------------------------------------------------------------

export const LIST_RESOLVERS = {
  attacks: (m, args = {}) => m.attacks
    .filter((a) => args.includeUnequipped !== false || a.equipped)
    .map((a) => ({
      name: a.name,
      bonus: a.toHit,
      damage: a.damageLabel,
      notes: joinNonEmpty([a.range, a.source === "spell" ? "" : a.notes], " · "),
      range: a.range,
      properties: a.notes,
    })),

  /** Spells with level >= minLevel (and <= maxLevel), sorted by level then name. */
  spells: (m, args = {}) => m.spellcasting.spells
    .filter((s) => s.level >= (args.minLevel ?? 1) && s.level <= (args.maxLevel ?? 9))
    .filter((s) => !args.preparedOnly || s.isPrepared)
    .map((s) => ({
      prep: s.prepared >= 1,
      name: s.name,
      level: String(s.level),
      school: s.schoolLabel,
      time: s.castingTimeShort,
      range: s.range,
      duration: s.durationShort,
      conc: s.concentration,
      ritual: s.ritual,
      notes: joinNonEmpty([s.componentsLabel, spellEffect(s, m)], " · "),
      levelLabel: s.levelLabel,
    })),

  cantrips: (m) => m.spellcasting.byLevel[0].map((s) => ({
    name: s.name,
    notes: joinNonEmpty([s.range, spellEffect(s, m) || s.durationShort], " · "),
  })),

  equipment: (m, args = {}) => m.equipment.items
    .filter((i) => !(args.skipZeroQuantity && !i.quantity))
    .map((i) => ({
      equipped: i.equipped,
      qty: String(i.quantity),
      name: `${i.depth ? "› ".repeat(i.depth) : ""}${i.name}${i.attuned ? " (E)" : ""}`,
      weight: i.weightNumber,
    })),

  resources: (m) => m.resources.map((r) => ({
    name: r.label,
    value: String(r.value),
    max: String(r.max),
    sr: /KR|SR/.test(r.recovery ?? ""),
    lr: /LR/.test(r.recovery ?? ""),
  })),
};

/** Short effect text for spell rows: to-hit/save + damage. */
function spellEffect(s, m) {
  const L = terms(m.meta.lang).words;
  const att = s.toHit ? s.toHit : s.save ? `${L.dc} ${s.save.dc ?? ""} ${s.save.abilityAbbr}`.trim() : "";
  return joinNonEmpty([att, s.damageLabel], " ");
}

/** Resolve a scalar mapping entry. */
export function resolveValue(entry, ctx) {
  const m = ctx.model;
  if ("const" in entry) return entry.const;
  if (entry.value) return get(m, entry.value) ?? "";
  const fn = RESOLVERS[entry.resolver];
  if (!fn) throw new Error(`Unknown resolver "${entry.resolver}" for field "${entry.field}"`);
  const args = entry.args ?? [];
  return fn(m, ...args, ctx);
}

/** Resolve a list mapping entry to rows. */
export function resolveList(list, ctx) {
  const fn = LIST_RESOLVERS[list.resolver];
  if (!fn) throw new Error(`Unknown list resolver "${list.resolver}" for list "${list.id}"`);
  return fn(ctx.model, list.args ?? {}, ctx);
}

export { dice };
