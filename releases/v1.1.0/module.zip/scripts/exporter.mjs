// Export pipeline inside Foundry: actor -> model -> filled PDF -> download.

import { MODULE_ID, getSetting } from "./settings.mjs";
import { BUILTIN_TEMPLATES, mappingForTemplate } from "./templates.mjs";
import { extractActor } from "./data-extract.mjs";
import { renderSheet } from "./pdf-engine.mjs";

const MODULE_PATH = `modules/${MODULE_ID}`;

/** All selectable templates: built-ins plus an optional user template from the settings. */
export function availableTemplates() {
  const list = BUILTIN_TEMPLATES
    // External (not shipped) PDFs only appear once their file is set in the module settings.
    .filter((t) => !t.external || getSetting(t.setting))
    .map((t) => ({
      ...t,
      builtin: true,
      file: t.external ? getSetting(t.setting) : t.file,
      fileIsModulePath: !t.external,
      label: game.i18n.localize(t.label),
    }));
  const file = getSetting("customTemplate");
  const mapping = getSetting("customMapping");
  if (file && mapping) {
    list.push({
      id: "custom", builtin: false, file, mapping,
      label: getSetting("customLabel") || game.i18n.localize("PNPSP.Template.Custom"),
      lang: getSetting("customLang") || "de",
    });
  }
  return list;
}

/**
 * Export a character sheet PDF.
 * @param {Actor} actor
 * @param {object} [opts]  { templateId, lang, flatten, spellCompendium, portrait, metric }
 * @returns {Promise<{filename: string, report: object}>}
 */
export async function exportActor(actor, opts = {}) {
  if (actor?.type !== "character") throw new Error(game.i18n.localize("PNPSP.Error.NotCharacter"));
  const template = availableTemplates().find((t) => t.id === (opts.templateId ?? getSetting("defaultTemplate")))
    ?? availableTemplates()[0];
  const lang = opts.lang && opts.lang !== "auto" ? opts.lang : template.lang;

  const [templateBytes, mapping] = await Promise.all([
    fetchBytes(resolvePath(template.file, template.builtin && template.fileIsModulePath)),
    fetchJson(resolvePath(template.mapping, template.builtin)),
  ]);

  const metricSetting = opts.metric ?? getSetting("metric");
  const metric = metricSetting === "metric" ? true : metricSetting === "imperial" ? false : "auto";
  const model = extractActor(actor, { lang, metric });

  let portrait = null;
  if ((opts.portrait ?? getSetting("includePortrait")) && mapping.portrait) {
    portrait = await loadPortrait(actor.img).catch((err) => {
      console.warn(`${MODULE_ID} | portrait could not be embedded`, err);
      return null;
    });
  }

  const { bytes, report } = await renderSheet({
    templateBytes,
    mapping: mappingForTemplate(mapping, template, lang),
    model,
    options: {
      flatten: opts.flatten ?? getSetting("flatten"),
      spellCompendium: opts.spellCompendium ?? getSetting("spellCompendium"),
      portrait,
    },
  });

  const filename = `${slugify(actor.name)}_${template.id}.pdf`;
  download(bytes, filename);
  console.info(`${MODULE_ID} | exported ${filename}`, { report, model });
  return { filename, report };
}

function resolvePath(path, builtin) {
  const p = builtin ? `${MODULE_PATH}/${path}` : path;
  return foundry.utils.getRoute ? foundry.utils.getRoute(p) : p;
}

async function fetchBytes(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(game.i18n.format("PNPSP.Error.Fetch", { url, status: res.status }));
  return new Uint8Array(await res.arrayBuffer());
}

async function fetchJson(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(game.i18n.format("PNPSP.Error.Fetch", { url, status: res.status }));
  return res.json();
}

/** Render the actor image to PNG bytes (handles webp/svg via canvas). Skips the default token icon. */
async function loadPortrait(src) {
  if (!src || /mystery-man|icons\/svg\//.test(src)) return null;
  const img = new Image();
  img.crossOrigin = "anonymous";
  img.src = foundry.utils.getRoute ? foundry.utils.getRoute(src) : src;
  await img.decode();
  const max = 900;
  const scale = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(img.naturalWidth * scale));
  canvas.height = Math.max(1, Math.round(img.naturalHeight * scale));
  canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
  const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
  if (!blob) return null;
  return { bytes: new Uint8Array(await blob.arrayBuffer()), type: "png" };
}

function download(bytes, filename) {
  const save = foundry.utils.saveDataToFile ?? globalThis.saveDataToFile;
  if (save) return save(bytes, "application/pdf", filename);
  const url = URL.createObjectURL(new Blob([bytes], { type: "application/pdf" }));
  const a = Object.assign(document.createElement("a"), { href: url, download: filename });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
}

function slugify(name) {
  return String(name ?? "charakter").normalize("NFKD").replace(/[̀-ͯ]/g, "")
    .replace(/[^\w\- ]+/g, "").trim().replace(/\s+/g, "_") || "charakter";
}
