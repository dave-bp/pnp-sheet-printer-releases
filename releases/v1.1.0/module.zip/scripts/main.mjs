// pnp-sheet-printer — entry point: settings, sheet header button, actor directory context entry, API.
// Foundry VTT v14 (>= 14.367), dnd5e 6.0.x. Read-only: the module never modifies actors or items.

import { MODULE_ID, registerSettings } from "./settings.mjs";
import { SheetExportDialog } from "./export-dialog.mjs";
import { exportActor, availableTemplates } from "./exporter.mjs";
import { extractActor, buildActorView } from "./data-extract.mjs";

/** Characters only; visible to owners and the GM. */
function canPrint(actor) {
  return actor?.type === "character" && (actor.isOwner || game.user.isGM);
}

function openDialog(actor) {
  const existing = foundry.applications.instances.get(`${MODULE_ID}-export-${actor.id}`);
  if (existing) return existing.render({ force: true });
  return new SheetExportDialog(actor).render({ force: true });
}

Hooks.once("init", () => {
  registerSettings();
});

Hooks.once("ready", () => {
  if (game.system.id !== "dnd5e") {
    console.warn(`${MODULE_ID} | requires the dnd5e system, found ${game.system.id}`);
    return;
  }
  // Small public API for macros: game.modules.get("pnp-sheet-printer").api
  game.modules.get(MODULE_ID).api = {
    openDialog,
    exportActor,
    extractActor,
    buildActorView,
    availableTemplates,
  };
});

// Header button on actor sheets (ApplicationV2). The hook fires for every class in the sheet's
// inheritance chain; ActorSheetV2 covers the dnd5e character sheet (BaseActorSheet extends ActorSheetV2).
// The generic ApplicationV2 hook is a fallback; the action check prevents a duplicate entry.
function addHeaderControl(app, controls) {
  const actor = app.document;
  if (actor?.documentName !== undefined && actor.documentName !== "Actor") return;
  if (!canPrint(actor)) return;
  if (controls.some((c) => c.action === "pnpspPrint")) return;
  controls.push({
    action: "pnpspPrint",
    icon: "fa-solid fa-print",
    label: "PNPSP.PrintSheet",
    onClick: () => openDialog(actor),
  });
}
Hooks.on("getHeaderControlsActorSheetV2", addHeaderControl);
Hooks.on("getHeaderControlsApplicationV2", addHeaderControl);

// Context menu entry in the Actors sidebar (same entry shape dnd5e 6 uses).
Hooks.on("getActorContextOptions", (app, entryOptions) => {
  if (app instanceof foundry.applications.sidebar.apps.Compendium) return;
  entryOptions.push({
    label: "PNPSP.PrintSheet",
    icon: "fa-solid fa-print",
    visible: (li) => canPrint(game.actors.get(li.dataset.entryId)),
    onClick: (event, target) => {
      const actor = game.actors.get(target.dataset.entryId);
      if (actor) openDialog(actor);
    },
  });
});
