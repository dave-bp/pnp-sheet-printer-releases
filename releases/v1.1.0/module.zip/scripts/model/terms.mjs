// Print-language dictionaries for dnd5e config keys (dnd5e 6.0.x).
// Independent of the Foundry UI language and of installed translation modules,
// so a sheet can be printed in German from an English client and vice versa.
// German terms follow the official German 5e translations (Ulisses / Spielerhandbuch).

const de = {
  abilities: {
    str: ["Stärke", "STÄ"], dex: ["Geschicklichkeit", "GES"], con: ["Konstitution", "KON"],
    int: ["Intelligenz", "INT"], wis: ["Weisheit", "WEI"], cha: ["Charisma", "CHA"],
  },
  skills: {
    acr: "Akrobatik", ani: "Mit Tieren umgehen", arc: "Arkane Kunde", ath: "Athletik",
    dec: "Täuschen", his: "Geschichte", ins: "Motiv erkennen", itm: "Einschüchtern",
    inv: "Nachforschungen", med: "Heilkunde", nat: "Naturkunde", prc: "Wahrnehmung",
    prf: "Auftreten", per: "Überzeugen", rel: "Religion", slt: "Fingerfertigkeit",
    ste: "Heimlichkeit", sur: "Überlebenskunst",
  },
  damageTypes: {
    acid: "Säure", bludgeoning: "Wucht", cold: "Kälte", fire: "Feuer", force: "Energie",
    lightning: "Blitz", necrotic: "Nekrotisch", piercing: "Stich", poison: "Gift",
    psychic: "Psychisch", radiant: "Gleißend", slashing: "Hieb", thunder: "Schall",
    healing: "Heilung", temphp: "Temporäre TP", midi: "", none: "",
  },
  spellSchools: {
    abj: "Bannzauber", con: "Beschwörung", div: "Erkenntnis", enc: "Verzauberung",
    evo: "Hervorrufung", ill: "Illusion", nec: "Nekromantie", trs: "Verwandlung",
  },
  spellLevels: ["Zaubertrick", "1. Grad", "2. Grad", "3. Grad", "4. Grad", "5. Grad",
    "6. Grad", "7. Grad", "8. Grad", "9. Grad"],
  languages: {
    common: "Gemeinsprache", draconic: "Drakonisch", dwarvish: "Zwergisch", elvish: "Elfisch",
    giant: "Riesisch", gnomish: "Gnomisch", goblin: "Goblinisch", halfling: "Halblingisch",
    orc: "Orkisch", sign: "Gebärdensprache", aarakocra: "Aarakocra", abyssal: "Abyssisch",
    cant: "Diebessprache", celestial: "Celestisch", deep: "Tiefensprache", druidic: "Druidisch",
    gith: "Gith", gnoll: "Gnollisch", infernal: "Infernalisch", primordial: "Urtümlich",
    aquan: "Aqual", auran: "Aural", ignan: "Ignal", terran: "Terral", sylvan: "Sylvanisch",
    undercommon: "Gemeinsprache der Unterreiche", ALL: "Alle Sprachen",
  },
  sizes: { tiny: "Winzig", sm: "Klein", med: "Mittelgroß", lg: "Groß", huge: "Riesig", grg: "Gigantisch" },
  armorProf: { lgt: "Leichte Rüstung", med: "Mittelschwere Rüstung", hvy: "Schwere Rüstung", shl: "Schilde" },
  weaponProf: { sim: "Einfache Waffen", mar: "Kriegswaffen" },
  weaponIds: {
    battleaxe: "Streitaxt", blowgun: "Blasrohr", club: "Knüppel", dagger: "Dolch", dart: "Wurfpfeil",
    flail: "Flegel", glaive: "Glefe", greataxe: "Zweihandaxt", greatclub: "Zweihandknüppel",
    greatsword: "Zweihandschwert", halberd: "Hellebarde", handaxe: "Beil", handcrossbow: "Handarmbrust",
    heavycrossbow: "Schwere Armbrust", javelin: "Wurfspeer", lance: "Lanze", lightcrossbow: "Leichte Armbrust",
    lighthammer: "Leichter Hammer", longbow: "Langbogen", longsword: "Langschwert", mace: "Streitkolben",
    maul: "Zweihandhammer", morningstar: "Morgenstern", musket: "Muskete", pike: "Pike", pistol: "Pistole",
    quarterstaff: "Kampfstab", rapier: "Rapier", scimitar: "Krummsäbel", shortsword: "Kurzschwert",
    sickle: "Sichel", spear: "Speer", shortbow: "Kurzbogen", sling: "Schleuder", trident: "Dreizack",
    warpick: "Kriegspicke", warhammer: "Kriegshammer", whip: "Peitsche",
  },
  armorIds: {
    breastplate: "Brustplatte", chainmail: "Kettenpanzer", chainshirt: "Kettenhemd", halfplate: "Halbplatte",
    hide: "Fellrüstung", leather: "Lederrüstung", padded: "Gepolsterte Rüstung", plate: "Ritterrüstung",
    ringmail: "Ringpanzer", scalemail: "Schuppenpanzer", splint: "Schienenpanzer", studded: "Beschlagene Lederrüstung",
    shield: "Schild",
  },
  tools: {
    alchemist: "Alchemistenausrüstung", brewer: "Brauerausrüstung", calligrapher: "Kalligrafenausrüstung",
    carpenter: "Zimmermannswerkzeug", cartographer: "Kartografenwerkzeug", cobbler: "Schusterwerkzeug",
    cook: "Kochutensilien", glassblower: "Glasbläserwerkzeug", jeweler: "Juwelierwerkzeug",
    leatherworker: "Lederverarbeitungswerkzeug", mason: "Maurerwerkzeug", painter: "Malerutensilien",
    potter: "Töpferwerkzeug", smith: "Schmiedewerkzeug", tinker: "Tüftlerwerkzeug", weaver: "Weberwerkzeug",
    woodcarver: "Holzschnitzwerkzeug", disg: "Verkleidungsausrüstung", forg: "Fälscherausrüstung",
    herb: "Kräuterkundeausrüstung", navg: "Navigationswerkzeug", pois: "Giftmischerausrüstung",
    thief: "Diebeswerkzeug", dice: "Würfelspiel", card: "Kartenspiel", chess: "Drachenschach",
    bagpipes: "Dudelsack", drum: "Trommel", dulcimer: "Hackbrett", flute: "Flöte", horn: "Horn",
    lute: "Laute", lyre: "Leier", panflute: "Panflöte", shawm: "Schalmei", viol: "Gambe",
    air: "Luftfahrzeuge", land: "Landfahrzeuge", space: "Raumfahrzeuge", water: "Wasserfahrzeuge",
    art: "Handwerkszeug", game: "Spielset", music: "Musikinstrument", vehicle: "Fahrzeuge",
  },
  senses: { darkvision: "Dunkelsicht", blindsight: "Blindsicht", tremorsense: "Erschütterungssinn", truesight: "Wahrsicht" },
  movement: { walk: "Gehen", fly: "Fliegen", swim: "Schwimmen", climb: "Klettern", burrow: "Graben" },
  periods: { lr: "LR", sr: "KR", day: "Tag", dawn: "Morgens", dusk: "Abends", charges: "Ladungen", recharge: "Aufladen" },
  conditions: {
    blinded: "Blind", charmed: "Bezaubert", deafened: "Taub", diseased: "Krank", exhaustion: "Erschöpfung",
    frightened: "Verängstigt", grappled: "Gepackt", incapacitated: "Kampfunfähig", invisible: "Unsichtbar",
    paralyzed: "Gelähmt", petrified: "Versteinert", poisoned: "Vergiftet", prone: "Liegend",
    restrained: "Festgesetzt", stunned: "Betäubt", unconscious: "Bewusstlos", surprised: "Überrascht",
  },
  classes: {
    artificer: "Magieschmied", barbarian: "Barbar", bard: "Barde", cleric: "Kleriker", druid: "Druide",
    fighter: "Kämpfer", monk: "Mönch", paladin: "Paladin", ranger: "Waldläufer", rogue: "Schurke",
    sorcerer: "Zauberer", warlock: "Hexenmeister", wizard: "Magier",
  },
  alignments: {
    "lawful good": "Rechtschaffen gut", "neutral good": "Neutral gut", "chaotic good": "Chaotisch gut",
    "lawful neutral": "Rechtschaffen neutral", "neutral": "Neutral", "true neutral": "Neutral",
    "chaotic neutral": "Chaotisch neutral", "lawful evil": "Rechtschaffen böse", "neutral evil": "Neutral böse",
    "chaotic evil": "Chaotisch böse", "unaligned": "Gesinnungslos", "any alignment": "Beliebige Gesinnung",
  },
  itemTypes: {
    weapon: "Waffe", equipment: "Ausrüstung", consumable: "Verbrauchsgut", tool: "Werkzeug",
    loot: "Beute", container: "Behälter", spell: "Zauber", feat: "Merkmal",
  },
  featureCategories: { class: "Klasse", race: "Spezies", background: "Hintergrund", feat: "Talent", other: "Sonstiges", supernaturalGift: "Übernatürliche Gabe", enchantment: "Verzauberung" },
  words: {
    self: "Selbst", touch: "Berührung", special: "Speziell", instantaneous: "Unmittelbar", permanent: "Permanent",
    concentration: "Konzentration", ritual: "Ritual", reach: "Reichweite", ammo: "Munition", proficient: "geübt",
    expertise: "Expertise", prepared: "vorbereitet", always: "immer", save: "RW", dc: "SG", attack: "Angriff",
    continued: "Fortsetzung", seeAppendix: "→ s. Anhang", none: "–", consumed: "verbraucht", attuned: "eingestimmt",
  },
  componentAbbr: { vocal: "V", somatic: "G", material: "M" },
  currency: { pp: "PM", gp: "GM", ep: "EM", sp: "SM", cp: "KM" },
  units: { ft: "ft", m: "m", mi: "mi", km: "km", lb: "Pfd.", kg: "kg", tn: "t" },
};

const en = {
  abilities: {
    str: ["Strength", "STR"], dex: ["Dexterity", "DEX"], con: ["Constitution", "CON"],
    int: ["Intelligence", "INT"], wis: ["Wisdom", "WIS"], cha: ["Charisma", "CHA"],
  },
  skills: {
    acr: "Acrobatics", ani: "Animal Handling", arc: "Arcana", ath: "Athletics", dec: "Deception",
    his: "History", ins: "Insight", itm: "Intimidation", inv: "Investigation", med: "Medicine",
    nat: "Nature", prc: "Perception", prf: "Performance", per: "Persuasion", rel: "Religion",
    slt: "Sleight of Hand", ste: "Stealth", sur: "Survival",
  },
  damageTypes: {
    acid: "Acid", bludgeoning: "Bludgeoning", cold: "Cold", fire: "Fire", force: "Force",
    lightning: "Lightning", necrotic: "Necrotic", piercing: "Piercing", poison: "Poison",
    psychic: "Psychic", radiant: "Radiant", slashing: "Slashing", thunder: "Thunder",
    healing: "Healing", temphp: "Temp HP", midi: "", none: "",
  },
  spellSchools: {
    abj: "Abjuration", con: "Conjuration", div: "Divination", enc: "Enchantment",
    evo: "Evocation", ill: "Illusion", nec: "Necromancy", trs: "Transmutation",
  },
  spellLevels: ["Cantrip", "1st Level", "2nd Level", "3rd Level", "4th Level", "5th Level",
    "6th Level", "7th Level", "8th Level", "9th Level"],
  languages: {
    common: "Common", draconic: "Draconic", dwarvish: "Dwarvish", elvish: "Elvish", giant: "Giant",
    gnomish: "Gnomish", goblin: "Goblin", halfling: "Halfling", orc: "Orc", sign: "Common Sign Language",
    aarakocra: "Aarakocra", abyssal: "Abyssal", cant: "Thieves' Cant", celestial: "Celestial",
    deep: "Deep Speech", druidic: "Druidic", gith: "Gith", gnoll: "Gnoll", infernal: "Infernal",
    primordial: "Primordial", aquan: "Aquan", auran: "Auran", ignan: "Ignan", terran: "Terran",
    sylvan: "Sylvan", undercommon: "Undercommon", ALL: "All Languages",
  },
  sizes: { tiny: "Tiny", sm: "Small", med: "Medium", lg: "Large", huge: "Huge", grg: "Gargantuan" },
  armorProf: { lgt: "Light Armor", med: "Medium Armor", hvy: "Heavy Armor", shl: "Shields" },
  weaponProf: { sim: "Simple Weapons", mar: "Martial Weapons" },
  weaponIds: {
    battleaxe: "Battleaxe", blowgun: "Blowgun", club: "Club", dagger: "Dagger", dart: "Dart", flail: "Flail",
    glaive: "Glaive", greataxe: "Greataxe", greatclub: "Greatclub", greatsword: "Greatsword", halberd: "Halberd",
    handaxe: "Handaxe", handcrossbow: "Hand Crossbow", heavycrossbow: "Heavy Crossbow", javelin: "Javelin",
    lance: "Lance", lightcrossbow: "Light Crossbow", lighthammer: "Light Hammer", longbow: "Longbow",
    longsword: "Longsword", mace: "Mace", maul: "Maul", morningstar: "Morningstar", musket: "Musket",
    pike: "Pike", pistol: "Pistol", quarterstaff: "Quarterstaff", rapier: "Rapier", scimitar: "Scimitar",
    shortsword: "Shortsword", sickle: "Sickle", spear: "Spear", shortbow: "Shortbow", sling: "Sling",
    trident: "Trident", warpick: "War Pick", warhammer: "Warhammer", whip: "Whip",
  },
  armorIds: {
    breastplate: "Breastplate", chainmail: "Chain Mail", chainshirt: "Chain Shirt", halfplate: "Half Plate",
    hide: "Hide", leather: "Leather", padded: "Padded", plate: "Plate", ringmail: "Ring Mail",
    scalemail: "Scale Mail", splint: "Splint", studded: "Studded Leather", shield: "Shield",
  },
  tools: {
    alchemist: "Alchemist's Supplies", brewer: "Brewer's Supplies", calligrapher: "Calligrapher's Supplies",
    carpenter: "Carpenter's Tools", cartographer: "Cartographer's Tools", cobbler: "Cobbler's Tools",
    cook: "Cook's Utensils", glassblower: "Glassblower's Tools", jeweler: "Jeweler's Tools",
    leatherworker: "Leatherworker's Tools", mason: "Mason's Tools", painter: "Painter's Supplies",
    potter: "Potter's Tools", smith: "Smith's Tools", tinker: "Tinker's Tools", weaver: "Weaver's Tools",
    woodcarver: "Woodcarver's Tools", disg: "Disguise Kit", forg: "Forgery Kit", herb: "Herbalism Kit",
    navg: "Navigator's Tools", pois: "Poisoner's Kit", thief: "Thieves' Tools", dice: "Dice Set",
    card: "Playing Card Set", chess: "Dragonchess Set", bagpipes: "Bagpipes", drum: "Drum",
    dulcimer: "Dulcimer", flute: "Flute", horn: "Horn", lute: "Lute", lyre: "Lyre", panflute: "Pan Flute",
    shawm: "Shawm", viol: "Viol", air: "Vehicles (Air)", land: "Vehicles (Land)", space: "Vehicles (Space)",
    water: "Vehicles (Water)", art: "Artisan's Tools", game: "Gaming Set", music: "Musical Instrument",
    vehicle: "Vehicles",
  },
  senses: { darkvision: "Darkvision", blindsight: "Blindsight", tremorsense: "Tremorsense", truesight: "Truesight" },
  movement: { walk: "Walk", fly: "Fly", swim: "Swim", climb: "Climb", burrow: "Burrow" },
  periods: { lr: "LR", sr: "SR", day: "Day", dawn: "Dawn", dusk: "Dusk", charges: "Charges", recharge: "Recharge" },
  conditions: {
    blinded: "Blinded", charmed: "Charmed", deafened: "Deafened", diseased: "Diseased", exhaustion: "Exhaustion",
    frightened: "Frightened", grappled: "Grappled", incapacitated: "Incapacitated", invisible: "Invisible",
    paralyzed: "Paralyzed", petrified: "Petrified", poisoned: "Poisoned", prone: "Prone",
    restrained: "Restrained", stunned: "Stunned", unconscious: "Unconscious", surprised: "Surprised",
  },
  classes: {
    artificer: "Artificer", barbarian: "Barbarian", bard: "Bard", cleric: "Cleric", druid: "Druid",
    fighter: "Fighter", monk: "Monk", paladin: "Paladin", ranger: "Ranger", rogue: "Rogue",
    sorcerer: "Sorcerer", warlock: "Warlock", wizard: "Wizard",
  },
  alignments: {},
  itemTypes: {
    weapon: "Weapon", equipment: "Equipment", consumable: "Consumable", tool: "Tool",
    loot: "Loot", container: "Container", spell: "Spell", feat: "Feature",
  },
  featureCategories: { class: "Class", race: "Species", background: "Background", feat: "Feat", other: "Other", supernaturalGift: "Supernatural Gift", enchantment: "Enchantment" },
  words: {
    self: "Self", touch: "Touch", special: "Special", instantaneous: "Instantaneous", permanent: "Permanent",
    concentration: "Concentration", ritual: "Ritual", reach: "Reach", ammo: "Ammunition", proficient: "proficient",
    expertise: "Expertise", prepared: "prepared", always: "always", save: "save", dc: "DC", attack: "Attack",
    continued: "continued", seeAppendix: "→ see appendix", none: "–", consumed: "consumed", attuned: "attuned",
  },
  componentAbbr: { vocal: "V", somatic: "S", material: "M" },
  currency: { pp: "PP", gp: "GP", ep: "EP", sp: "SP", cp: "CP" },
  units: { ft: "ft", m: "m", mi: "mi", km: "km", lb: "lb", kg: "kg", tn: "tn" },
};

// Activation, time, range and weapon property terms (keys from CONFIG.DND5E, dnd5e 6.0.6).
Object.assign(de, {
  activation: {
    action: ["Aktion", "Aktionen"], bonus: ["Bonusaktion", "Bonusaktionen"], reaction: ["Reaktion", "Reaktionen"],
    minute: ["Minute", "Minuten"], hour: ["Stunde", "Stunden"], day: ["Tag", "Tage"],
    longRest: ["Lange Rast", "Lange Rasten"], shortRest: ["Kurze Rast", "Kurze Rasten"],
    encounter: ["Begegnung", "Begegnungen"], turnStart: ["Zugbeginn", "Zugbeginn"], turnEnd: ["Zugende", "Zugende"],
    legendary: ["Legendäre Aktion", "Legendäre Aktionen"], mythic: ["Mythische Aktion", "Mythische Aktionen"],
    lair: ["Hortaktion", "Hortaktionen"], crew: ["Crew-Aktion", "Crew-Aktionen"], special: ["Speziell", "Speziell"],
  },
  time: {
    turn: ["Zug", "Züge"], round: ["Runde", "Runden"], second: ["Sekunde", "Sekunden"],
    minute: ["Minute", "Minuten"], hour: ["Stunde", "Stunden"], day: ["Tag", "Tage"], week: ["Woche", "Wochen"],
    month: ["Monat", "Monate"], year: ["Jahr", "Jahre"], inst: ["Unmittelbar"], spec: ["Speziell"],
    perm: ["Permanent"], disp: ["Bis gebannt"], dstr: ["Bis gebannt oder ausgelöst"],
  },
  timeShort: {
    turn: ["Zug", "Züge"], round: ["Runde", "Runden"], second: ["Sek.", "Sek."], minute: ["Min.", "Min."],
    hour: ["Std.", "Std."], day: ["Tag", "Tage"], week: ["Woche", "Wochen"], month: ["Monat", "Monate"],
    year: ["Jahr", "Jahre"], inst: ["Sofort"], spec: ["Speziell"], perm: ["Permanent"], disp: ["Bis gebannt"],
    dstr: ["Bis gebannt/ausgelöst"],
  },
  rangeTypes: { self: "Selbst", touch: "Berührung", spec: "Speziell", any: "Beliebig" },
  weaponProperties: {
    ada: "Adamant", amm: "Munition", fin: "Finesse", fir: "Feuerwaffe", foc: "Fokus", hvy: "Schwer",
    lgt: "Leicht", lod: "Laden", mgc: "Magisch", rch: "Reichweite", rel: "Nachladen", ret: "Zurückkehrend",
    sil: "Versilbert", spc: "Speziell", thr: "Wurfwaffe", two: "Zweihändig", ver: "Vielseitig",
  },
  masteries: {
    cleave: "Spalten", graze: "Streifen", nick: "Einkerben", push: "Stoßen", sap: "Schwächen",
    slow: "Verlangsamen", topple: "Umstoßen", vex: "Plagen",
  },
});
Object.assign(en, {
  activation: {
    action: ["Action", "Actions"], bonus: ["Bonus Action", "Bonus Actions"], reaction: ["Reaction", "Reactions"],
    minute: ["Minute", "Minutes"], hour: ["Hour", "Hours"], day: ["Day", "Days"],
    longRest: ["Long Rest", "Long Rests"], shortRest: ["Short Rest", "Short Rests"],
    encounter: ["Encounter", "Encounters"], turnStart: ["Turn Start", "Turn Start"], turnEnd: ["Turn End", "Turn End"],
    legendary: ["Legendary Action", "Legendary Actions"], mythic: ["Mythic Action", "Mythic Actions"],
    lair: ["Lair Action", "Lair Actions"], crew: ["Crew Action", "Crew Actions"], special: ["Special", "Special"],
  },
  time: {
    turn: ["Turn", "Turns"], round: ["Round", "Rounds"], second: ["Second", "Seconds"],
    minute: ["Minute", "Minutes"], hour: ["Hour", "Hours"], day: ["Day", "Days"], week: ["Week", "Weeks"],
    month: ["Month", "Months"], year: ["Year", "Years"], inst: ["Instantaneous"], spec: ["Special"],
    perm: ["Permanent"], disp: ["Until Dispelled"], dstr: ["Until Dispelled or Triggered"],
  },
  timeShort: {
    turn: ["Turn", "Turns"], round: ["Round", "Rounds"], second: ["Sec.", "Sec."], minute: ["Min.", "Min."],
    hour: ["Hr.", "Hrs."], day: ["Day", "Days"], week: ["Week", "Weeks"], month: ["Month", "Months"],
    year: ["Year", "Years"], inst: ["Instant."], spec: ["Special"], perm: ["Permanent"], disp: ["Until dispelled"],
    dstr: ["Until dispelled/triggered"],
  },
  rangeTypes: { self: "Self", touch: "Touch", spec: "Special", any: "Any" },
  weaponProperties: {
    ada: "Adamantine", amm: "Ammunition", fin: "Finesse", fir: "Firearm", foc: "Focus", hvy: "Heavy",
    lgt: "Light", lod: "Loading", mgc: "Magical", rch: "Reach", rel: "Reload", ret: "Returning",
    sil: "Silvered", spc: "Special", thr: "Thrown", two: "Two-Handed", ver: "Versatile",
  },
  masteries: {
    cleave: "Cleave", graze: "Graze", nick: "Nick", push: "Push", sap: "Sap", slow: "Slow", topple: "Topple", vex: "Vex",
  },
});

export const TERMS = { de, en };

/** Get the dictionary for a print language (falls back to English). */
export function terms(lang) {
  return TERMS[lang] ?? TERMS.en;
}

/** Look up a keyed term with fallback to a provided default (usually Foundry's own label). */
export function term(lang, group, key, fallback = "") {
  const v = terms(lang)[group]?.[key];
  if (Array.isArray(v)) return v[0];
  return v ?? fallback ?? key;
}
