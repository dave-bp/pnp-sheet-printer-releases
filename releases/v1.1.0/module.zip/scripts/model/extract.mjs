// Pure extraction: prepared dnd5e actor view -> version-neutral character model.
//
// Input ("ActorView") is the shape produced by scripts/data-extract.mjs from a live actor and by
// tools/dump-prepared-actor.js as JSON:
//   { name, img, type, system (PREPARED), items: [{ id, name, type, img, sort, system, labels,
//     activities: [{ id, type, name, labels, ... }] }], meta: { rulesVersion, systemVersion, ... } }
//
// All dnd5e data paths used here were verified against dnd5e 6.0.6 source
// (module/data/actor/**, module/data/item/**, module/data/activity/**). See docs/MAPPING.md.

import { terms, term } from "./terms.mjs";
import { htmlToText, summarize, signed, length, weight, joinNonEmpty, num, dice } from "./text.mjs";

export const MODEL_VERSION = 1;

const ABILITIES = ["str", "dex", "con", "int", "wis", "cha"];
const SKILLS = {
  acr: "dex", ani: "wis", arc: "int", ath: "str", dec: "cha", his: "int", ins: "wis", itm: "cha", inv: "int",
  med: "wis", nat: "int", prc: "wis", prf: "cha", per: "cha", rel: "int", slt: "dex", ste: "dex", sur: "wis",
};

/** Normalize Set | Array | {value: Set|Array} | object-map to an array. */
function arr(x) {
  if (!x) return [];
  if (Array.isArray(x)) return x;
  if (x instanceof Set) return Array.from(x);
  if (typeof x[Symbol.iterator] === "function" && typeof x !== "string") return Array.from(x);
  if (typeof x === "object") return Object.keys(x).filter((k) => x[k]);
  return [x];
}
const n = (v, d = 0) => (Number.isFinite(Number(v)) && v !== null && v !== "" ? Number(v) : d);
const plural = (pair, count) => (Array.isArray(pair) ? (count === 1 ? pair[0] : (pair[1] ?? pair[0])) : pair);

/**
 * Build the character model.
 * @param {object} view       ActorView (see header)
 * @param {object} [options]
 * @param {"de"|"en"} [options.lang="de"]         Print language for terms and number formatting
 * @param {boolean|"auto"} [options.metric="auto"] Convert ft/lb to m/kg ("auto": when lang is de)
 * @param {boolean} [options.translateNames=true]  Translate SRD class names by identifier
 * @param {(id:string)=>string} [options.nameOf]   Resolver for @UUID links in descriptions
 */
export function extractCharacter(view, options = {}) {
  const o = { lang: "de", metric: "auto", translateNames: true, ...options };
  const L = terms(o.lang);
  const sys = view.system ?? {};
  // Dump format nests activity fields under `data`; live adapter passes them flat. Normalize to flat.
  const items = (view.items ?? []).map((i) => ({
    ...i,
    activities: arr(i.activities).map((a) => (isDumpedActivity(a) ? { ...a.data, id: a.id, type: a.type, name: a.name, labels: a.labels } : a)),
  })).sort((a, b) => n(a.sort) - n(b.sort));
  const byType = (t) => items.filter((i) => i.type === t);
  const fmtLen = (v, u) => length(v, u, o);
  const text = (html) => htmlToText(html, { nameOf: o.nameOf });

  // ---------- identity ----------
  const classItems = byType("class");
  const subclassItems = byType("subclass");
  const classes = classItems
    .map((c) => {
      const id = c.system?.identifier ?? "";
      const sub = subclassItems.find((s) => s.system?.classIdentifier === id);
      return {
        id: c.id,
        identifier: id,
        name: (o.translateNames && L.classes[id]) || c.name,
        subclass: sub?.name ?? "",
        levels: n(c.system?.levels, 0),
        hitDie: c.system?.hd?.denomination ?? "",
        hitDiceMax: n(c.system?.hd?.max, n(c.system?.levels)),
        hitDiceValue: n(c.system?.hd?.value, n(c.system?.hd?.max, n(c.system?.levels)) - n(c.system?.hd?.spent)),
        preparedMax: Number.isFinite(Number(c.system?.spellcasting?.preparation?.max)) && c.system?.spellcasting?.preparation?.max !== null
          ? Number(c.system.spellcasting.preparation.max) : null,
        spellcasting: c.system?.spellcasting?.progression && c.system.spellcasting.progression !== "none"
          ? { progression: c.system.spellcasting.progression, ability: c.system.spellcasting.ability ?? "" }
          : null,
        isOriginal: c.id === sys.details?.originalClass,
      };
    })
    .sort((a, b) => (b.isOriginal - a.isOriginal) || (b.levels - a.levels));
  const race = byType("race")[0];
  const background = byType("background")[0];
  const level = n(sys.details?.level, classes.reduce((s, c) => s + c.levels, 0));
  const alignmentRaw = sys.details?.alignment ?? "";
  const identity = {
    name: view.name ?? "",
    img: view.img ?? "",
    player: view.playerName ?? "",
    level,
    classes,
    classLabel: classes.map((c) => joinNonEmpty([`${c.name} ${c.levels}`, c.subclass ? `(${c.subclass})` : ""], " ")).join(" / "),
    classShort: classes.map((c) => `${c.name} ${c.levels}`).join(" / "),
    subclassLabel: classes.map((c) => c.subclass).filter(Boolean).join(" / "),
    species: race?.name ?? "",
    background: background?.name ?? "",
    alignment: L.alignments[alignmentRaw.toLowerCase().trim()] ?? alignmentRaw,
    size: term(o.lang, "sizes", sys.traits?.size, sys.traits?.size ?? ""),
    creatureType: sys.details?.type?.value ?? "",
    xp: { value: n(sys.details?.xp?.value), max: Number.isFinite(sys.details?.xp?.max) ? sys.details.xp.max : null },
    rulesVersion: view.meta?.rulesVersion ?? "modern",
  };

  // ---------- abilities ----------
  const abilities = {};
  for (const k of ABILITIES) {
    const a = sys.abilities?.[k] ?? {};
    const score = n(a.value, 10);
    const mod = n(a.mod, Math.floor((score - 10) / 2));
    abilities[k] = {
      key: k,
      label: L.abilities[k][0],
      abbr: L.abilities[k][1],
      score,
      mod,
      modLabel: signed(mod),
      save: n(a.save?.value, mod),
      saveLabel: signed(n(a.save?.value, mod)),
      saveProf: n(a.proficient, 0) >= 1,
      check: n(a.check?.value, mod),
      dc: n(a.dc, 8 + mod + n(sys.attributes?.prof)),
    };
  }

  // ---------- skills ----------
  const skills = {};
  for (const [k, defAbl] of Object.entries(SKILLS)) {
    const s = sys.skills?.[k] ?? {};
    const ability = s.ability || defAbl;
    const prof = n(s.value ?? s.proficient, 0); // 0, 0.5, 1, 2 (verified creature.mjs: value = prof.multiplier)
    const total = n(s.total, abilities[ability].mod);
    skills[k] = {
      key: k,
      label: L.skills[k],
      ability,
      abilityAbbr: L.abilities[ability]?.[1] ?? ability,
      total,
      totalLabel: signed(total),
      prof,
      proficient: prof >= 1,
      expertise: prof >= 2,
      half: prof === 0.5,
      passive: n(s.passive, 10 + total),
    };
  }

  // ---------- combat ----------
  const attr = sys.attributes ?? {};
  const speeds = attr.movement?.speeds ?? {};
  const moveUnits = attr.movement?.units ?? "ft";
  const speedParts = Object.keys(L.movement)
    .filter((k) => n(speeds[k]) > 0)
    .map((k) => ({ key: k, label: L.movement[k], value: n(speeds[k]), formatted: fmtLen(speeds[k], moveUnits) }));
  const hitDice = Object.values(classes.reduce((acc, c) => {
    if (!c.hitDie) return acc;
    acc[c.hitDie] ??= { die: c.hitDie, max: 0, value: 0 };
    acc[c.hitDie].max += c.hitDiceMax;
    acc[c.hitDie].value += c.hitDiceValue;
    return acc;
  }, {})).sort((a, b) => parseInt(b.die.slice(1)) - parseInt(a.die.slice(1)));
  const hp = attr.hp ?? {};
  const combat = {
    prof: n(attr.prof, 2),
    profLabel: signed(n(attr.prof, 2)),
    ac: n(attr.ac?.value, 10 + abilities.dex.mod),
    acLabel: attr.ac?.label ?? "",
    initiative: n(attr.init?.total, abilities.dex.mod),
    initiativeLabel: signed(n(attr.init?.total, abilities.dex.mod)),
    speed: speedParts.find((s) => s.key === "walk")?.formatted ?? fmtLen(n(speeds.walk), moveUnits),
    speeds: speedParts,
    speedsLabel: speedParts.filter((s) => s.key !== "walk").map((s) => `${s.label} ${s.formatted}`).join(", "),
    hp: {
      value: n(hp.value), max: n(hp.max), temp: n(hp.temp), tempmax: n(hp.tempmax),
    },
    hitDice,
    hitDiceLabel: hitDice.map((h) => dice(`${h.max}${h.die}`, o.lang)).join(" + "),
    hitDiceRemainingLabel: hitDice.map((h) => dice(`${h.value}${h.die}`, o.lang)).join(" + "),
    hitDiceRemaining: hitDice.reduce((s, h) => s + h.value, 0),
    deathSaves: { success: n(attr.death?.success), failure: n(attr.death?.failure) },
    inspiration: !!attr.inspiration,
    exhaustion: n(attr.exhaustion),
    concentrationSave: n(attr.concentration?.save, abilities.con.save),
    conditions: arr(view.statuses).filter((k) => k !== "exhaustion" && L.conditions[k]).map((k) => L.conditions[k]),
    passive: { prc: skills.prc.passive, ins: skills.ins.passive, inv: skills.inv.passive },
  };

  // ---------- senses ----------
  const ranges = attr.senses?.ranges ?? {};
  const senseUnits = attr.senses?.units ?? "ft";
  const senses = Object.keys(L.senses)
    .filter((k) => n(ranges[k]) > 0)
    .map((k) => `${L.senses[k]} ${fmtLen(ranges[k], senseUnits)}`);
  if (attr.senses?.special) senses.push(...String(attr.senses.special).split(";").map((s) => s.trim()).filter(Boolean));

  // ---------- proficiencies ----------
  const tr = sys.traits ?? {};
  const traitList = (field, group) => [
    ...arr(field?.value).map((k) => term(o.lang, group, k, k)),
    ...String(field?.custom ?? "").split(";").map((s) => s.trim()).filter(Boolean),
  ];
  const tools = Object.entries(sys.tools ?? {}).map(([k, t]) => ({
    key: k,
    label: term(o.lang, "tools", k, byType("tool").find((i) => i.system?.type?.baseItem === k)?.name ?? k),
    total: n(t.total), totalLabel: signed(n(t.total)), prof: n(t.value), ability: t.ability ?? "",
  }));
  const languageKeys = arr(tr.languages?.value);
  const proficiencies = {
    armor: traitList(tr.armorProf, "armorProf").map((s) => term(o.lang, "armorIds", s, s)),
    weapons: traitList(tr.weaponProf, "weaponProf").map((s) => term(o.lang, "weaponIds", s, s)),
    weaponMasteries: arr(tr.weaponProf?.mastery?.value).map((k) => term(o.lang, "weaponIds", k, k)),
    tools,
    languages: [
      ...languageKeys.map((k) => term(o.lang, "languages", k, k)),
      ...String(tr.languages?.custom ?? "").split(";").map((s) => s.trim()).filter(Boolean),
    ],
  };
  proficiencies.armorLabel = proficiencies.armor.join(", ");
  proficiencies.weaponsLabel = proficiencies.weapons.join(", ");
  proficiencies.toolsLabel = tools.map((t) => t.label).join(", ");
  proficiencies.languagesLabel = proficiencies.languages.join(", ");

  const dmgList = (field) => [
    ...arr(field?.value).map((k) => term(o.lang, "damageTypes", k, k)),
    ...String(field?.custom ?? "").split(";").map((s) => s.trim()).filter(Boolean),
  ];
  const defenses = {
    resistances: dmgList(tr.dr),
    immunities: dmgList(tr.di),
    vulnerabilities: dmgList(tr.dv),
    conditionImmunities: [
      ...arr(tr.ci?.value).map((k) => term(o.lang, "conditions", k, k)),
      ...String(tr.ci?.custom ?? "").split(";").map((s) => s.trim()).filter(Boolean),
    ],
  };

  // ---------- attacks ----------
  const attacks = [];
  const damageFrom = (activity) => arr(activity?.labels?.damage ?? activity?.labels?.damages).map((d) => {
    if (typeof d === "string") return { formula: dice(d, o.lang), type: "", label: dice(d, o.lang) };
    const typeLabel = d.damageType ? term(o.lang, "damageTypes", d.damageType, "") : "";
    const formula = dice(d.formula ?? "", o.lang);
    return { formula, type: d.damageType ?? "", label: joinNonEmpty([formula, typeLabel], " ") || d.label || "" };
  });
  const weaponRange = (w) => {
    const r = w.system?.range ?? {};
    const u = r.units ?? "ft";
    const parts = [];
    if (n(r.reach) > 0) parts.push(fmtLen(r.reach, u));
    if (n(r.value) > 0) parts.push(n(r.long) > n(r.value) ? `${fmtLen(r.value, u).replace(/ \S+$/, "")}/${fmtLen(r.long, u)}` : fmtLen(r.value, u));
    return parts.join(", ") || w.labels?.range || "";
  };
  for (const w of byType("weapon")) {
    const equipped = w.system?.equipped !== false;
    const attack = (w.activities ?? []).find((a) => a.type === "attack");
    const props = arr(w.system?.properties).filter((p) => L.weaponProperties[p] && p !== "mgc");
    const mastery = w.system?.mastery ? term(o.lang, "masteries", w.system.mastery, w.system.mastery) : "";
    attacks.push({
      id: w.id,
      source: "weapon",
      name: w.name,
      equipped,
      toHit: attack?.labels?.toHit ?? "",
      damage: damageFrom(attack),
      damageLabel: damageFrom(attack).map((d) => d.label).join(" + ") || joinNonEmpty([dice(w.labels?.damage, o.lang), w.labels?.damageTypes], " "),
      range: weaponRange(w),
      properties: props.map((p) => L.weaponProperties[p]),
      mastery,
      notes: joinNonEmpty([props.map((p) => L.weaponProperties[p]).join(", "), mastery ? `${o.lang === "de" ? "Meisterschaft" : "Mastery"}: ${mastery}` : ""], "; "),
    });
  }
  // Order: equipped weapons first, then the rest
  attacks.sort((a, b) => (b.equipped - a.equipped));

  // ---------- spellcasting ----------
  const spellItems = byType("spell");
  const slots = [];
  for (let lvl = 1; lvl <= 9; lvl++) {
    const s = sys.spells?.[`spell${lvl}`];
    if (s && n(s.max) > 0) slots.push({ level: lvl, max: n(s.max), value: n(s.value) });
  }
  const pactSrc = sys.spells?.pact;
  const pact = pactSrc && n(pactSrc.max) > 0 ? { level: n(pactSrc.level), max: n(pactSrc.max), value: n(pactSrc.value) } : null;
  const castingAbilityKeys = [...new Set(classes.map((c) => c.spellcasting?.ability).filter(Boolean))];
  const mainAbility = attr.spellcasting || castingAbilityKeys[0] || "";
  const castingClasses = classes.filter((c) => c.spellcasting).map((c) => {
    const ab = c.spellcasting.ability || mainAbility;
    return {
      name: c.name, identifier: c.identifier, ability: ab,
      abilityLabel: L.abilities[ab]?.[0] ?? "",
      dc: abilities[ab]?.dc ?? null,
      preparedMax: c.preparedMax,
      attack: abilities[ab] ? abilities[ab].mod + combat.prof + n(sys.abilities?.[ab]?.attack?.bonus) : null,
    };
  });
  for (const c of castingClasses) c.attackLabel = c.attack === null ? "" : signed(c.attack);

  const spells = spellItems.map((s) => spellModel(s, { o, L, text, fmtLen, damageFrom, castingClasses }))
    .sort((a, b) => (a.level - b.level) || a.name.localeCompare(b.name, o.lang));
  const spellcasting = {
    hasSpells: spells.length > 0 || slots.length > 0 || !!pact,
    ability: mainAbility,
    abilityLabel: L.abilities[mainAbility]?.[0] ?? "",
    abilityAbbr: L.abilities[mainAbility]?.[1] ?? "",
    dc: mainAbility ? n(attr.spell?.dc, abilities[mainAbility].dc) : null,
    attack: mainAbility ? n(attr.spell?.attack, abilities[mainAbility].mod + combat.prof) : null,
    classes: castingClasses,
    classLabel: castingClasses.map((c) => c.name).join(" / "),
    preparedMax: castingClasses.some((c) => c.preparedMax !== null)
      ? castingClasses.reduce((s, c) => s + (c.preparedMax ?? 0), 0) : null,
    slots,
    pact,
    spells,
    byLevel: Array.from({ length: 10 }, (_, lvl) => spells.filter((s) => s.level === lvl)),
  };
  spellcasting.attackLabel = spellcasting.attack === null ? "" : signed(spellcasting.attack);

  // Spell attacks with to-hit/damage also count as "attacks" (cantrips like Fire Bolt).
  for (const s of spells) {
    if (s.level === 0 && (s.toHit || s.save) && s.damageLabel) {
      attacks.push({
        id: s.id, source: "spell", name: s.name, equipped: true,
        toHit: s.toHit || (s.save ? `${L.words.dc} ${s.save.dc} ${s.save.abilityAbbr}` : ""),
        damage: s.damage, damageLabel: s.damageLabel, range: s.range, properties: [], mastery: "",
        notes: L.spellLevels[0],
      });
    }
  }

  // ---------- features ----------
  const features = byType("feat").map((f) => {
    const cat = f.system?.type?.value || "other";
    const uses = usesModel(f, L);
    const desc = text(f.system?.description?.value);
    return {
      id: f.id,
      name: f.name,
      category: cat,
      categoryLabel: L.featureCategories[cat] ?? L.featureCategories.other,
      subtype: f.system?.type?.subtype ?? "",
      requirements: f.system?.requirements ?? "",
      uses,
      activation: activationLabel(f.system?.activities ? null : f.system?.activation, L) || activityActivation(f, L),
      description: desc,
      summary: summarize(desc, 260),
    };
  });
  const catOrder = { class: 0, race: 1, background: 2, feat: 3 };
  features.sort((a, b) => (catOrder[a.category] ?? 9) - (catOrder[b.category] ?? 9));

  // ---------- inventory ----------
  const PHYSICAL = ["weapon", "equipment", "consumable", "tool", "loot", "container"];
  const physical = items.filter((i) => PHYSICAL.includes(i.type));
  const ids = new Set(physical.map((i) => i.id));
  const containerOf = (i) => {
    const c = i.system?.container;
    const id = typeof c === "string" ? c : c?.id ?? null;
    return id && ids.has(id) ? id : null;
  };
  const invEntry = (i, depth) => {
    const q = n(i.system?.quantity, 1);
    const w = n(i.system?.weight?.value);
    const wu = i.system?.weight?.units ?? "lb";
    const uses = usesModel(i, L);
    return {
      id: i.id,
      name: i.name,
      type: i.type,
      typeLabel: L.itemTypes[i.type] ?? i.type,
      quantity: q,
      weight: w,
      weightUnits: wu,
      totalWeight: q * w,
      weightLabel: w ? weight(q * w, wu, o) : "",
      // Number without unit in print units (German: lb -> kg, 1 lb = 0.5 kg)
      weightNumber: w ? num((wu === "lb" && (o.metric === true || (o.metric === "auto" && o.lang === "de"))) ? (q * w) / 2 : q * w, o.lang, 2) : "",
      equipped: !!i.system?.equipped,
      attuned: !!i.system?.attuned,
      attunement: i.system?.attunement ?? "",
      magical: arr(i.system?.properties).includes("mgc"),
      rarity: i.system?.rarity ?? "",
      uses,
      depth,
      container: containerOf(i),
      isContainer: i.type === "container",
      summary: summarize(text(i.system?.description?.value), 160),
    };
  };
  const inventory = [];
  const walk = (parentId, depth) => {
    for (const i of physical.filter((x) => containerOf(x) === parentId)) {
      inventory.push(invEntry(i, depth));
      if (i.type === "container") walk(i.id, depth + 1);
    }
  };
  walk(null, 0);
  const cur = sys.currency ?? {};
  const enc = attr.encumbrance ?? {};
  const encUnits = view.meta?.weightUnits ?? (inventory.find((i) => i.weight)?.weightUnits ?? "lb");
  const equipment = {
    items: inventory,
    currency: { pp: n(cur.pp), gp: n(cur.gp), ep: n(cur.ep), sp: n(cur.sp), cp: n(cur.cp) },
    currencyLabel: ["pp", "gp", "ep", "sp", "cp"].filter((k) => n(cur[k])).map((k) => `${n(cur[k])} ${L.currency[k]}`).join(", "),
    totalGold: Math.round((n(cur.pp) * 10 + n(cur.gp) + n(cur.ep) * 0.5 + n(cur.sp) * 0.1 + n(cur.cp) * 0.01) * 100) / 100,
    encumbrance: {
      value: n(enc.value), max: Number.isFinite(enc.max) ? enc.max : null,
      encumbered: n(enc.thresholds?.encumbered, null), heavilyEncumbered: n(enc.thresholds?.heavilyEncumbered, null),
      units: encUnits,
      valueLabel: weight(n(enc.value), encUnits, o),
      maxLabel: Number.isFinite(enc.max) ? weight(enc.max, encUnits, o) : "",
    },
    attunement: { value: inventory.filter((i) => i.attuned).length, max: n(attr.attunement?.max, 3) },
  };

  // ---------- resources (limited uses worth tracking at the table) ----------
  const resources = [];
  for (const key of ["primary", "secondary", "tertiary"]) {
    const r = sys.resources?.[key];
    if (r?.label && (n(r.max) > 0 || n(r.value) > 0)) {
      resources.push({ label: r.label, value: n(r.value), max: n(r.max), recovery: r.lr ? L.periods.lr : r.sr ? L.periods.sr : "" });
    }
  }
  for (const f of features) {
    if (f.uses && f.uses.max > 0) resources.push({ label: f.name, value: f.uses.value, max: f.uses.max, recovery: f.uses.recovery });
  }

  // ---------- persona ----------
  const d = sys.details ?? {};
  const persona = {
    traits: d.trait ?? "",
    ideals: d.ideal ?? "",
    bonds: d.bond ?? "",
    flaws: d.flaw ?? "",
    appearance: d.appearance ?? "",
    biography: text(d.biography?.value),
    age: d.age ?? "", height: d.height ?? "", weight: d.weight ?? "", eyes: d.eyes ?? "",
    hair: d.hair ?? "", skin: d.skin ?? "", gender: d.gender ?? "", faith: d.faith ?? "",
  };

  return {
    modelVersion: MODEL_VERSION,
    meta: {
      lang: o.lang,
      metric: o.metric,
      source: view.meta?.source ?? "foundry",
      synthetic: !!view.meta?.synthetic,
      systemVersion: view.meta?.systemVersion ?? "",
      foundryVersion: view.meta?.foundryVersion ?? "",
      rulesVersion: identity.rulesVersion,
    },
    identity,
    abilities,
    skills,
    combat,
    senses,
    sensesLabel: senses.join(", "),
    proficiencies,
    defenses,
    attacks,
    spellcasting,
    features,
    equipment,
    resources,
    persona,
  };
}

// ---------- helpers ----------

/** Dump format ({ id, type, name, labels, data }) vs. a live Activity (fields flat, has `activation`). */
function isDumpedActivity(a) {
  return !!a && typeof a === "object" && a.data && typeof a.data === "object" && !("activation" in a) && !("attack" in a);
}

function usesModel(item, L) {
  const u = item.system?.uses;
  if (!u) return null;
  const max = n(u.max, 0);
  if (!max) return null;
  const value = Number.isFinite(Number(u.value)) && u.value !== null ? Number(u.value) : Math.max(max - n(u.spent), 0);
  const recovery = arr(u.recovery).map((r) => (typeof r === "string" ? r : r.period))
    .filter(Boolean).map((p) => L.periods[p] ?? p).join(", ");
  return { value, max, recovery };
}

function activationLabel(act, L, short = false) {
  if (!act?.type) return "";
  const pair = (short && L.timeShort[act.type]) || L.activation[act.type];
  if (!pair) return "";
  const v = n(act.value, 0) || 1;
  const counted = ["action", "bonus", "reaction", "minute", "hour", "day", "legendary", "mythic", "crew", "lair"].includes(act.type);
  return counted ? `${v} ${plural(pair, v)}` : plural(pair, 1);
}

function activityActivation(item, L) {
  const acts = item.activities ?? [];
  const a = acts.find((x) => x.activation?.type || x.data?.activation?.type);
  const act = a?.activation ?? a?.data?.activation;
  return activationLabel(act, L);
}

function durationLabel(dur, L, lang, short = false) {
  if (!dur?.units) return "";
  const pair = (short ? L.timeShort : L.time)[dur.units];
  if (!pair) return "";
  const v = n(dur.value, 0);
  const isScalar = !["inst", "spec", "perm", "disp", "dstr"].includes(dur.units);
  const base = isScalar && v ? `${v} ${plural(pair, v)}` : plural(pair, 1);
  return base;
}

function rangeLabel(range, L, fmtLen) {
  if (!range?.units) return L.rangeTypes.self;
  if (L.rangeTypes[range.units]) return L.rangeTypes[range.units];
  if (n(range.value) > 0) return fmtLen(range.value, range.units);
  return "";
}

function spellModel(s, { o, L, text, fmtLen, damageFrom, castingClasses }) {
  const sy = s.system ?? {};
  const props = arr(sy.properties);
  const acts = s.activities ?? [];
  const attack = acts.find((a) => a.type === "attack");
  const save = acts.find((a) => a.type === "save");
  const dmgAct = attack ?? save ?? acts.find((a) => a.type === "damage" || a.type === "heal");
  const damage = damageFrom(dmgAct);
  const saveAbility = arr(save?.save?.ability ?? save?.data?.save?.ability)[0] ?? "";
  const saveDc = save?.save?.dc?.value ?? save?.data?.save?.dc?.value ?? null;
  const description = text(sy.description?.value);
  const concentration = props.includes("concentration");
  const ritual = props.includes("ritual");
  const dur = durationLabel(sy.duration, L, o.lang);
  const durShort = durationLabel(sy.duration, L, o.lang, true);
  const sourceClass = String(sy.sourceItem ?? "").replace(/^class:/, "");
  const cls = castingClasses.find((c) => c.identifier === sourceClass);
  return {
    id: s.id,
    name: s.name,
    level: n(sy.level, 0),
    levelLabel: L.spellLevels[n(sy.level, 0)] ?? "",
    school: sy.school ?? "",
    schoolLabel: term(o.lang, "spellSchools", sy.school, sy.school ?? ""),
    method: sy.method ?? "",
    prepared: n(sy.prepared, 0),          // 0 unprepared, 1 prepared, 2 always (CONFIG.DND5E.spellPreparationStates)
    isPrepared: n(sy.prepared, 0) >= 1 || n(sy.level, 0) === 0,
    alwaysPrepared: n(sy.prepared, 0) === 2,
    sourceClass: cls?.name ?? "",
    components: {
      vocal: props.includes("vocal"), somatic: props.includes("somatic"), material: props.includes("material"),
      materials: sy.materials?.value ?? "",
      consumed: !!sy.materials?.consumed,
      cost: n(sy.materials?.cost, 0),
    },
    componentsLabel: [props.includes("vocal") && L.componentAbbr.vocal, props.includes("somatic") && L.componentAbbr.somatic,
      props.includes("material") && L.componentAbbr.material].filter(Boolean).join(", "),
    concentration,
    ritual,
    castingTime: activationLabel(sy.activation, L) + (ritual ? ` (${L.words.ritual})` : ""),
    castingTimeShort: activationLabel(sy.activation, L, true),
    range: rangeLabel(sy.range, L, fmtLen),
    target: s.labels?.target ?? "",
    duration: dur,
    durationShort: durShort,
    durationFull: concentration && dur ? `${L.words.concentration}, ${dur}` : dur,
    toHit: attack?.labels?.toHit ?? "",
    save: saveAbility ? { ability: saveAbility, abilityAbbr: L.abilities[saveAbility]?.[1] ?? saveAbility, dc: saveDc } : null,
    damage,
    damageLabel: damage.map((d) => d.label).join(" + "),
    description,
    summary: summarize(description, 220),
  };
}

export { ABILITIES, SKILLS, num };
