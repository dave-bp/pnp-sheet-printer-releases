// Pure text helpers: Foundry HTML/enricher -> printable plain text, number formatting.

const ENTITIES = { amp: "&", lt: "<", gt: ">", quot: "\"", apos: "'", nbsp: " ", ndash: "–", mdash: "—",
  hellip: "…", times: "×", minus: "−", rsquo: "’", lsquo: "‘", rdquo: "”", ldquo: "„", bdquo: "„",
  auml: "ä", ouml: "ö", uuml: "ü", Auml: "Ä", Ouml: "Ö", Uuml: "Ü", szlig: "ß", deg: "°", frac12: "½" };

function decodeEntities(s) {
  return s.replace(/&(#x?[0-9a-f]+|\w+);/gi, (m, e) => {
    if (e[0] === "#") {
      const code = e[1].toLowerCase() === "x" ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      return Number.isFinite(code) ? String.fromCodePoint(code) : m;
    }
    return ENTITIES[e] ?? m;
  });
}

/**
 * Resolve Foundry/dnd5e inline enrichers to readable text.
 *  @UUID[...]{Label} -> Label, @UUID[Compendium.x.y.Item.id] -> last segment (best effort),
 *  [[/r 1d6+2]]{x} -> x | 1d6+2, [[/damage 2d6 fire]] -> 2d6 fire, [[/save dex 15]] -> DEX 15,
 *  &Reference[prone] -> prone, [[lookup @name]] -> "".
 */
export function resolveEnrichers(s, { nameOf } = {}) {
  if (!s) return "";
  return s
    // @Embed[...] blocks cannot be printed
    .replace(/@Embed\[[^\]]*\](\{[^}]*\})?/g, "")
    // Labeled document links
    .replace(/@(UUID|Compendium|Item|Actor|JournalEntry|RollTable|Macro|Scene)\[[^\]]*\]\{([^}]*)\}/g, "$2")
    // Unlabeled links: try a resolver, else take the readable tail of the id
    .replace(/@(UUID|Compendium|Item|Actor|JournalEntry|RollTable)\[([^\]]*)\]/g, (m, t, id) => {
      const name = nameOf?.(id);
      if (name) return name;
      const tail = id.split(".").pop();
      return /^[A-Za-z0-9]{16}$/.test(tail) ? "" : tail;
    })
    .replace(/&Reference\[([^\]]+?)(\s[^\]]*)?\](\{([^}]*)\})?/g, (m, key, _o, _l, label) => label ?? key)
    // Inline rolls with explicit label
    .replace(/\[\[\/?\w*\s*([^\]]*?)\]\]\{([^}]*)\}/g, "$2")
    .replace(/\[\[\/(r|roll|pr|publicroll|gmr|br|sr)\s+([^\]]*?)\]\]/g, "$2")
    .replace(/\[\[\/(damage|heal|healing)\s+([^\]]*?)\]\]/g, (m, _t, f) => f.replace(/\s+average(=\w+)?/g, "").replace(/\s*type=/g, " ").trim())
    .replace(/\[\[\/(save|check|skill|tool)\s+([^\]]*?)\]\]/g, (m, kind, args) => {
      const parts = args.replace(/(ability|skill|dc|format)=/g, "").split(/\s+/).filter((p) => p && !/^(long|short|format)$/.test(p));
      return parts.map((p) => (/^[a-z]{3}$/.test(p) ? p.toUpperCase() : p)).join(" ");
    })
    .replace(/\[\[\/(item|activity)\s+([^\]]*?)\]\]/g, "$2")
    .replace(/\[\[lookup[^\]]*\]\]/g, "")
    .replace(/\[\[([^\]]*)\]\]/g, "$1");
}

/** Convert (enriched) HTML to plain text with paragraph and list structure preserved. */
export function htmlToText(html, opts = {}) {
  if (!html) return "";
  let s = resolveEnrichers(String(html), opts);
  s = s
    .replace(/<\s*(script|style)[^>]*>[\s\S]*?<\/\s*\1\s*>/gi, "")
    .replace(/<\s*br\s*\/?>/gi, "\n")
    .replace(/<\s*li[^>]*>/gi, "\n• ")
    .replace(/<\s*\/\s*(p|div|h[1-6]|ul|ol|table|tr|blockquote|section|header|footer)\s*>/gi, "\n")
    .replace(/<\s*\/\s*li\s*>/gi, "")
    .replace(/<\s*(p|div|h[1-6]|ul|ol|table|tr|blockquote|section)[^>]*>/gi, "\n")
    .replace(/<\s*\/\s*t[dh]\s*>/gi, " | ")
    .replace(/<[^>]+>/g, "");
  s = decodeEntities(s)
    .replace(/ /g, " ")
    .replace(/[ \t]+/g, " ")
    .replace(/ *\| *\n/g, "\n")
    .replace(/ *\n */g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .replace(/\n{2,}•/g, "\n•")
    .trim();
  return s;
}

/** First paragraph / sentence-limited summary of a text. */
export function summarize(text, maxChars = 240) {
  if (!text) return "";
  const first = text.split(/\n\n/)[0].replace(/\n/g, " ");
  if (first.length <= maxChars) return first;
  const cut = first.slice(0, maxChars);
  const dot = cut.lastIndexOf(". ");
  return (dot > maxChars * 0.5 ? cut.slice(0, dot + 1) : cut.replace(/\s+\S*$/, "")) + " …";
}

/** Signed modifier: 2 -> "+2", -1 -> "−1" (typographic minus optional). */
export function signed(n, { typographic = false } = {}) {
  if (n === null || n === undefined || n === "" || Number.isNaN(Number(n))) return "";
  const v = Number(n);
  if (v > 0) return `+${v}`;
  if (v < 0) return typographic ? `−${Math.abs(v)}` : `${v}`;
  return "+0";
}

/** Locale-aware number (German decimal comma). */
export function num(n, lang = "de", digits = 1) {
  if (n === null || n === undefined || n === "" || !Number.isFinite(Number(n))) return "";
  return Number(n).toLocaleString(lang === "de" ? "de-DE" : "en-US", { maximumFractionDigits: digits });
}

/**
 * Format a length. German printing converts feet to metres using the official 5 ft = 1.5 m rule.
 * @param {number} value
 * @param {string} units  dnd5e unit key ("ft", "m", "mi", "km")
 * @param {object} o      { lang, metric: boolean|"auto" }
 */
export function length(value, units = "ft", { lang = "de", metric = "auto" } = {}) {
  if (value === null || value === undefined || value === "" || !Number.isFinite(Number(value))) return "";
  let v = Number(value);
  let u = units || "ft";
  const toMetric = metric === true || (metric === "auto" && lang === "de");
  if (toMetric && u === "ft") { v = Math.round((v / 5) * 1.5 * 10) / 10; u = "m"; }
  if (toMetric && u === "mi") { v = Math.round(v * 1.5 * 10) / 10; u = "km"; }
  return `${num(v, lang)} ${u}`;
}

/** Format a weight in the given units, optionally converting lb -> kg for German printing. */
export function weight(value, units = "lb", { lang = "de", metric = "auto" } = {}) {
  if (value === null || value === undefined || !Number.isFinite(Number(value))) return "";
  let v = Number(value);
  let u = units || "lb";
  const toMetric = metric === true || (metric === "auto" && lang === "de");
  if (toMetric && u === "lb") { v = v / 2; u = "kg"; } // official German conversion: 1 lb ≈ 0.5 kg
  const unitLabel = u === "lb" ? (lang === "de" ? "Pfd." : "lb") : u;
  return `${num(v, lang, 2)} ${unitLabel}`;
}

/** Join non-empty strings. */
export function joinNonEmpty(parts, sep = ", ") {
  return parts.filter((p) => p !== null && p !== undefined && String(p).trim() !== "").join(sep);
}

/**
 * Normalize a dice formula for print: "1d6 + 3" -> "1d6+3"; German uses W ("1W6+3").
 * Leaves non-dice text untouched.
 */
export function dice(formula, lang = "de") {
  if (!formula) return "";
  let s = String(formula).replace(/\s*([+\-])\s*/g, "$1").replace(/\+-/g, "-").trim();
  if (lang === "de") s = s.replace(/(\d*)d(\d+)/g, "$1W$2");
  return s;
}
