// Foundry adapter: live, PREPARED dnd5e actor -> ActorView -> character model.
// This is the only file that touches dnd5e document objects; scripts/model/extract.mjs is pure.
// Read-only: nothing here writes to actors or items.

import { extractCharacter } from "./model/extract.mjs";

/**
 * Build the ActorView consumed by extractCharacter(). Reads the prepared data that dnd5e computed in
 * prepareData() (actor.system after preparation), never stored source data.
 * @param {Actor} actor  dnd5e character actor
 * @returns {object}
 */
export function buildActorView(actor) {
  const items = actor.items.contents.map((item) => ({
    id: item.id,
    name: item.name,
    type: item.type,
    img: item.img,
    sort: item.sort,
    system: item.system,
    labels: item.labels ?? {},
    activities: item.system.activities?.contents ?? [],
  }));
  return {
    id: actor.id,
    name: actor.name,
    img: actor.img,
    type: actor.type,
    playerName: playerNameFor(actor),
    system: actor.system,
    items,
    statuses: Array.from(actor.statuses ?? []),
    meta: {
      source: "foundry",
      foundryVersion: game.version,
      systemVersion: game.system.version,
      rulesVersion: safeSetting("dnd5e", "rulesVersion") ?? "modern",
      weightUnits: safeSetting("dnd5e", "metricWeightUnits") ? "kg" : "lb",
    },
  };
}

/**
 * Extract the print model for an actor.
 * @param {Actor} actor
 * @param {object} options  { lang, metric }
 */
export function extractActor(actor, options = {}) {
  const view = buildActorView(actor);
  return extractCharacter(view, {
    ...options,
    nameOf: (uuid) => {
      try { return foundry.utils.fromUuidSync?.(uuid)?.name ?? globalThis.fromUuidSync?.(uuid)?.name ?? ""; } catch { return ""; }
    },
  });
}

/** Name of the player who owns the character: assigned user first, then any non-GM owner. */
function playerNameFor(actor) {
  const assigned = game.users.find((u) => u.character?.id === actor.id);
  if (assigned) return assigned.name;
  const owner = game.users.find((u) => !u.isGM && actor.testUserPermission(u, "OWNER"));
  return owner?.name ?? "";
}

function safeSetting(ns, key) {
  try { return game.settings.get(ns, key); } catch { return undefined; }
}
