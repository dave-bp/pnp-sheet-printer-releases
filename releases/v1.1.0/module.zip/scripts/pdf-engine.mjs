// PDF engine: fills AcroForm templates from the neutral character model via a declarative mapping,
// handles overflow (auto-shrink -> truncate -> appendix pages) and renders appendix pages
// (overflow lists, long texts, optional spell compendium). Knows nothing about Foundry or dnd5e.
// Runs in the browser (Foundry) and in Node (tests) with the bundled pdf-lib.

import {
  PDFDocument, PDFTextField, PDFCheckBox, PDFButton, PDFName, StandardFonts, rgb, fontkit,
  defaultTextFieldAppearanceProvider,
} from "../vendor/pdf-lib.mjs";
import { resolveValue, resolveList } from "./resolvers/index.mjs";

const DEFAULTS = {
  flatten: false,          // true: bake fields into page content (print-only)
  appendix: true,          // add appendix pages for overflow
  spellCompendium: "prepared", // "none" | "prepared" | "all": spell description pages
  minFontSize: 6,
  portrait: null,          // { bytes: Uint8Array, type: "png"|"jpg" }
};

/** Characters WinAnsi-encoded standard fonts cannot show, mapped to safe stand-ins. */
const CHAR_MAP = { "−": "-", "→": "»", "←": "«", "⇒": "»", "≥": ">=", "≤": "<=", "✓": "x", "✔": "x", "★": "*",
  " ": " ", " ": " ", "​": "", "‑": "-", "‐": "-", "′": "'", "″": "\"", "⁄": "/" };

/**
 * Fill a template.
 * @param {object} p
 * @param {Uint8Array|ArrayBuffer} p.templateBytes
 * @param {object} p.mapping   Mapping definition (mappings/*.mapping.json)
 * @param {object} p.model     Character model (scripts/model/extract.mjs)
 * @param {object} [p.options]
 * @returns {Promise<{bytes: Uint8Array, report: object}>}
 */
export async function renderSheet({ templateBytes, mapping, model, options = {} }) {
  // English printing uses the mapping's English labels and appendix titles when provided.
  if (mapping.lang === "en" && mapping.labelsEn) mapping = { ...mapping, labels: mapping.labelsEn };
  const titleOf = (e, fallback) => (mapping.lang === "en" && e.appendixTitleEn) || e.appendixTitle || fallback;
  const opts = { ...DEFAULTS, ...(mapping.defaults ?? {}), ...options };
  const doc = await PDFDocument.load(templateBytes, { updateMetadata: false });
  doc.registerFontkit(fontkit);
  const form = doc.getForm();
  const fonts = await loadFonts(doc, mapping);
  const fieldFont = fonts.field;
  const report = { filled: 0, emptyValues: 0, missingFields: [], shrunk: [], truncated: [], appendix: [] };
  const appendix = [];
  const sanitize = makeSanitizer(fieldFont);

  // Index fields by name once
  const fields = new Map(form.getFields().map((f) => [f.getName(), f]));
  const touched = new Set();

  // 1) Clear every field: templates may ship with sample values.
  for (const f of fields.values()) {
    if (f instanceof PDFTextField) { if (f.getText()) { f.setText(""); touched.add(f); } }
    else if (f instanceof PDFCheckBox) setCheckbox(f, false);
  }

  const ctx = { model, lang: mapping.lang ?? model.meta?.lang ?? "de", mapping };

  // 2) Scalar fields
  for (const entry of mapping.fields ?? []) {
    const value = resolveValue(entry, ctx);
    if (entry.fallback && value && !fitsWithoutTruncation(entry.field, value, entry)) {
      // Primary (full) text does not fit: print the fallback (e.g. summaries), full text goes to the appendix.
      const short = resolveValue({ ...entry, ...entry.fallback }, ctx);
      writeField(entry.field, short, { ...entry, overflow: "truncate" });
      if (opts.appendix) appendix.push({ kind: "text", title: titleOf(entry, entry.field), text: sanitize(String(value)), full: true });
      report.appendix.push(`${entry.field}: full text`);
      continue;
    }
    writeField(entry.field, value, entry);
  }

  // 3) Lists (rows of fields)
  for (const list of mapping.lists ?? []) {
    const rows = resolveList(list, ctx);
    // Rows are addressed either by a name pattern ("spell_{nn}_name") or by explicit per-row field names
    // (templates with irregular names, e.g. the official sheet's "ZB17" / "Check Box44").
    const capacity = list.rowFields ? list.rowFields.length : list.rows;
    const start = list.start ?? 1;
    rows.slice(0, capacity).forEach((row, i) => {
      const idx = start + i;
      const columns = list.rowFields ? list.rowFields[i] : list.columns;
      for (const [col, pattern] of Object.entries(columns)) {
        if (!(col in row) || !pattern) continue;
        const name = list.rowFields ? pattern : fieldName(pattern, idx);
        writeField(name, row[col], { ...list, ...(list.columnOptions?.[col] ?? {}) });
      }
    });
    if (rows.length > capacity && !list.overflowToField) {
      report.appendix.push(`${list.id}: ${rows.length - capacity} more`);
      if (opts.appendix) appendix.push({ kind: "table", title: titleOf(list, list.id), columns: list.appendixColumns, rows: rows.slice(capacity) });
    }
  }

  // 4) Portrait image
  if (mapping.portrait && opts.portrait?.bytes) {
    try {
      const btn = form.getButton(mapping.portrait);
      const img = opts.portrait.type === "png" ? await doc.embedPng(opts.portrait.bytes) : await doc.embedJpg(opts.portrait.bytes);
      btn.setImage(img);
    } catch (err) { report.portraitError = String(err?.message ?? err); }
  }

  // 5) Appearances for all touched text fields in the template's field font
  // Only regenerate appearances of text fields we changed (filled or cleared). A global
  // form.updateFieldAppearances() would also restyle checkboxes that lack an /Off appearance.
  for (const f of touched) f.updateAppearances(fieldFont, widgetAlignedProvider);

  // 6) Appendix pages
  if (opts.appendix) {
    if (opts.spellCompendium !== "none" && model.spellcasting?.spells?.length) {
      const spells = model.spellcasting.spells.filter((s) => opts.spellCompendium === "all" || s.isPrepared);
      if (spells.length) appendix.push({ kind: "spells", title: mapping.labels?.spellCompendium ?? "Zauberbeschreibungen", spells });
    }
    if (appendix.length) await renderAppendix(doc, appendix, fonts, model, mapping, sanitize);
  }

  if (opts.flatten) form.flatten({ updateFieldAppearances: false });
  doc.setTitle(`${model.identity?.name ?? ""} – ${mapping.name ?? "Charakterbogen"}`);
  doc.setProducer("pnp-sheet-printer (pdf-lib)");
  const bytes = await doc.save({ updateFieldAppearances: false });
  return { bytes, report };

  // ---------- local helpers ----------

  /** Some templates keep /DA only on the widget or the AcroForm; pdf-lib needs it on the field. */
  function ensureDefaultAppearance(field) {
    const acro = field.acroField;
    if (acro.getDefaultAppearance?.()) return;
    const widgetDa = acro.getWidgets().map((w) => w.getDefaultAppearance?.()).find(Boolean);
    const formDa = form.acroForm.dict.lookup(PDFName.of("DA"))?.decodeText?.()
      ?? form.acroForm.dict.lookup(PDFName.of("DA"))?.asString?.();
    acro.setDefaultAppearance(widgetDa || formDa || "/Helv 0 Tf 0 g");
  }

  function fitsWithoutTruncation(name, value, entry) {
    const f = fields.get(name);
    if (!(f instanceof PDFTextField)) return true;
    ensureDefaultAppearance(f);
    return !fitText(f, sanitize(String(value)), entry).truncated;
  }

  function writeField(name, value, entry = {}) {
    const f = fields.get(name);
    if (!f) { report.missingFields.push(name); return; }
    if (f instanceof PDFCheckBox) {
      setCheckbox(f, !!value);
      if (value) report.filled++;
      return;
    }
    if (!(f instanceof PDFTextField)) return;
    // Booleans in text fields (e.g. an inspiration box that is a text field) print as a mark.
    let text = value === null || value === undefined || value === false ? "" : value === true ? "X" : String(value);
    text = sanitize(text);
    if (!text) { report.emptyValues++; return; }
    if (entry.maxChars && text.length > entry.maxChars) text = text.slice(0, entry.maxChars - 1) + "…";
    ensureDefaultAppearance(f);
    const fitted = fitText(f, text, entry);
    f.setText(fitted.text);
    touched.add(f);
    if (fitted.size) f.setFontSize(fitted.size);
    applyWidgetSizes(f, fitted, entry);
    report.filled++;
    if (fitted.shrunk) report.shrunk.push(name);
    if (fitted.truncated) {
      report.truncated.push(name);
      if (opts.appendix && entry.overflow === "appendix") {
        appendix.push({ kind: "text", title: titleOf(entry, name), text });
      }
    }
  }

  /**
   * pdf-lib prefers a widget's own /DA over the field's. Widgets of mirrored fields (e.g. the name on every
   * page) carry their own sizes, so size each widget for its own rectangle.
   */
  function applyWidgetSizes(field, fitted, entry) {
    const widgets = field.acroField.getWidgets();
    const fieldDa = field.acroField.getDefaultAppearance?.() ?? "";
    for (const w of widgets) {
      const ownDa = w.getDefaultAppearance?.();
      if (!ownDa && widgets.length === 1) continue;
      const da = ownDa || fieldDa;
      const r = w.getRectangle();
      const width = r.width - 8;
      let size = fitted.size || Number((da.match(/([\d.]+)\s+Tf/) ?? [])[1] ?? 0) || Math.min(11, r.height * 0.78);
      const ownSize = Number((da.match(/([\d.]+)\s+Tf/) ?? [])[1] ?? 0);
      if (ownSize && ownSize < size) size = ownSize;
      if (!field.isMultiline()) {
        const min = entry.minFontSize ?? opts.minFontSize;
        while (size > min && fieldFont.widthOfTextAtSize(fitted.text.split("\n")[0], size) > width) size -= 0.25;
      }
      w.setDefaultAppearance(da.replace(/[\d.]+\s+Tf/, `${Math.round(size * 4) / 4} Tf`));
    }
  }

  /** Find a font size (and possibly a truncation) that makes text fit into the field's widget. */
  function fitText(field, text, entry) {
    // Mirrored fields have several widgets of different sizes: fit into the smallest one.
    const rect = field.acroField.getWidgets().map((w) => w.getRectangle())
      .reduce((a, b) => (b.width * b.height < a.width * a.height ? b : a));
    const da = field.acroField.getDefaultAppearance?.() ?? "";
    const daSize = Number((da.match(/([\d.]+)\s+Tf/) ?? [])[1] ?? 0);
    const multiline = field.isMultiline();
    const min = entry.minFontSize ?? opts.minFontSize;
    const pad = 3;
    const width = rect.width - pad * 2;
    const height = rect.height - pad * 2;

    if (!multiline) {
      // Auto-size fields (0 Tf): pick an explicit size like Acrobat would (capped), big boxes may go larger.
      const autoCap = entry.maxFontSize ?? (rect.height > 24 ? rect.height * 0.62 : Math.min(11, rect.height * 0.78));
      const start = daSize || autoCap;
      let size = start;
      while (size > min && fieldFont.widthOfTextAtSize(text, size) > width) size -= 0.25;
      if (fieldFont.widthOfTextAtSize(text, size) <= width) {
        return { text, size: daSize && size >= daSize ? null : Math.round(size * 4) / 4, shrunk: size < start };
      }
      // Truncate with ellipsis at min size
      let t = text;
      while (t.length > 1 && fieldFont.widthOfTextAtSize(t + "…", min) > width) t = t.slice(0, -1);
      return { text: t.trimEnd() + "…", size: min, shrunk: true, truncated: true };
    }

    const start = daSize || entry.fontSize || 9;
    for (let size = start; size >= min; size -= 0.5) {
      const lines = wrap(text, fieldFont, size, width);
      if (lines.length * lineHeight(fieldFont, size) <= height) {
        return { text, size, shrunk: size < start };
      }
    }
    // Truncate: keep as many lines as fit at min size, mark continuation
    const lines = wrap(text, fieldFont, min, width);
    const maxLines = Math.max(1, Math.floor(height / lineHeight(fieldFont, min)));
    const note = mapping.labels?.seeAppendix ?? "… (Fortsetzung im Anhang)";
    const kept = lines.slice(0, maxLines - 1).join("\n");
    return { text: `${kept}\n${note}`, size: min, shrunk: true, truncated: true };
  }
}

/** Load fonts declared by the mapping (standard fonts or embedded TTF bytes). */
async function loadFonts(doc, mapping) {
  const f = mapping.fonts ?? {};
  const std = (name, fallback) => doc.embedFont(StandardFonts[name] ?? StandardFonts[fallback]);
  return {
    field: await std(f.field ?? "TimesRoman", "TimesRoman"),
    body: await std(f.body ?? "TimesRoman", "TimesRoman"),
    bold: await std(f.bold ?? "TimesRomanBold", "TimesRomanBold"),
    italic: await std(f.italic ?? "TimesRomanItalic", "TimesRomanItalic"),
  };
}

/** Build a sanitizer that keeps only characters the font can encode. */
function makeSanitizer(font) {
  let charset = null;
  try { charset = new Set(font.getCharacterSet()); } catch { charset = null; }
  return (s) => {
    let out = "";
    for (const ch of String(s).replace(/\r\n?/g, "\n")) {
      const mapped = CHAR_MAP[ch] ?? ch;
      for (const c of mapped) {
        const cp = c.codePointAt(0);
        if (c === "\n" || !charset || charset.has(cp)) out += c;
        else if (/\s/.test(c)) out += " ";
        else out += "?";
      }
    }
    return out;
  };
}

/**
 * Text appearance provider that honours each widget's own /Q (alignment). pdf-lib reads only the field's /Q,
 * but templates may align mirrored widgets differently (e.g. centred on page 1, right-aligned in page headers).
 */
function widgetAlignedProvider(field, widget, font) {
  const Q = PDFName.of("Q");
  const wq = widget.dict.get(Q);
  const fieldDict = field.acroField.dict;
  const fq = fieldDict.get(Q);
  if (wq) fieldDict.set(Q, wq);
  try {
    return defaultTextFieldAppearanceProvider(field, widget, font);
  } finally {
    if (fq) fieldDict.set(Q, fq);
    else if (wq) fieldDict.delete(Q);
  }
}

/** Check/uncheck while keeping the template's own appearance streams (sets /V and /AS only). */
function setCheckbox(cb, on) {
  const acro = cb.acroField;
  const onValue = acro.getOnValue?.() ?? PDFName.of("Yes");
  const v = on ? onValue : PDFName.of("Off");
  acro.dict.set(PDFName.of("V"), v);
  for (const w of acro.getWidgets()) {
    const wOn = w.getOnValue?.() ?? onValue;
    w.dict.set(PDFName.of("AS"), on ? wOn : PDFName.of("Off"));
  }
}

function fieldName(pattern, idx) {
  return pattern.replace("{nn}", String(idx).padStart(2, "0")).replace("{n}", String(idx));
}

function lineHeight(font, size) {
  return font.heightAtSize(size) * 1.12;
}

/** Word-wrap text (respecting explicit newlines) to a width. */
export function wrap(text, font, size, width) {
  const out = [];
  for (const para of String(text).split("\n")) {
    if (!para.trim()) { out.push(""); continue; }
    let line = "";
    for (const word of para.split(/\s+/)) {
      const candidate = line ? `${line} ${word}` : word;
      if (font.widthOfTextAtSize(candidate, size) <= width) { line = candidate; continue; }
      if (line) out.push(line);
      // Hard-break very long words
      let w = word;
      while (font.widthOfTextAtSize(w, size) > width && w.length > 1) {
        let cut = w.length - 1;
        while (cut > 1 && font.widthOfTextAtSize(w.slice(0, cut), size) > width) cut--;
        out.push(w.slice(0, cut));
        w = w.slice(cut);
      }
      line = w;
    }
    out.push(line);
  }
  return out;
}

// ---------------------------------------------------------------------------
// Appendix rendering: clean two-column pages in the sheet's colours.
// ---------------------------------------------------------------------------

async function renderAppendix(doc, sections, fonts, model, mapping, sanitize) {
  const first = doc.getPage(0);
  const { width: W, height: H } = first.getSize();
  const style = {
    // Narrow (phone) pages: one column and slim margins; landscape/portrait A4: two columns.
    margin: W < 450 ? 18 : 42, gutter: 18, accent: hex(mapping.style?.accent ?? "#7a1f1f"), ink: hex(mapping.style?.ink ?? "#2b2118"),
    muted: hex(mapping.style?.muted ?? "#6b5a48"), rule: hex(mapping.style?.rule ?? "#c9b48a"),
    paper: mapping.style?.paper ? hex(mapping.style.paper) : null,
  };
  const L = mapping.labels ?? {};
  const cols = W < 450 ? 1 : 2;
  const colW = (W - style.margin * 2 - style.gutter * (cols - 1)) / cols;
  let page; let col = 0; let y = 0; let pageNo = 0;

  const newPage = () => {
    page = doc.addPage([W, H]);
    pageNo++;
    if (style.paper) page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: style.paper });
    const title = sanitize(`${L.appendix ?? "Anhang"} · ${model.identity?.name ?? ""}`);
    page.drawText(title, { x: style.margin, y: H - style.margin + 6, size: W < 450 ? 11 : 13, font: fonts.bold, color: style.accent });
    page.drawLine({ start: { x: style.margin, y: H - style.margin }, end: { x: W - style.margin, y: H - style.margin }, thickness: 0.8, color: style.rule });
    page.drawText(sanitize(`${mapping.name ?? ""} · ${L.appendix ?? "Anhang"} ${pageNo}`), {
      x: style.margin, y: style.margin - 22, size: 7.5, font: fonts.italic, color: style.muted,
    });
    col = 0; y = H - style.margin - 14;
  };
  const x0 = () => style.margin + col * (colW + style.gutter);
  const ensure = (h) => {
    if (!page) newPage();
    if (y - h < style.margin) {
      if (col < cols - 1) { col++; y = H - style.margin - 14; }
      else newPage();
    }
  };
  const heading = (text) => {
    ensure(30);
    y -= 6;
    page.drawText(sanitize(text), { x: x0(), y: y - 11, size: 11.5, font: fonts.bold, color: style.accent });
    y -= 15;
    page.drawLine({ start: { x: x0(), y }, end: { x: x0() + colW, y }, thickness: 0.5, color: style.rule });
    y -= 6;
  };
  const para = (text, { size = 8.5, font = fonts.body, color = style.ink, indent = 0, gap = 2 } = {}) => {
    const lines = wrap(sanitize(text), font, size, colW - indent);
    const lh = lineHeight(font, size);
    for (const line of lines) {
      ensure(lh);
      if (line) page.drawText(line, { x: x0() + indent, y: y - size, size, font, color });
      y -= lh;
    }
    y -= gap;
  };

  newPage();
  for (const s of sections) {
    if (s.kind === "text") {
      heading(`${s.title} (${L.continued ?? "Fortsetzung"})`);
      para(s.text);
    } else if (s.kind === "table") {
      heading(`${s.title} (${L.continued ?? "Fortsetzung"})`);
      for (const row of s.rows) {
        const cols = s.columns ?? Object.keys(row);
        const main = row[cols[0]] ?? "";
        const rest = cols.slice(1).map((c) => row[c]).filter((v) => v !== "" && v !== null && v !== undefined && v !== false && v !== true).join(" · ");
        ensure(lineHeight(fonts.body, 8.5));
        para(rest ? `${main} — ${rest}` : String(main), { gap: 1 });
      }
    } else if (s.kind === "spells") {
      heading(s.title);
      let lastLevel = null;
      for (const sp of s.spells) {
        if (sp.level !== lastLevel) {
          ensure(20);
          y -= 2;
          para(sp.levelLabel, { size: 9.5, font: fonts.bold, color: style.muted, gap: 1 });
          lastLevel = sp.level;
        }
        ensure(40);
        const flags = [sp.concentration ? (L.concentrationShort ?? "K") : "", sp.ritual ? (L.ritualShort ?? "R") : ""].filter(Boolean).join(", ");
        para(`${sp.name}${flags ? ` [${flags}]` : ""}`, { size: 9.5, font: fonts.bold, color: style.accent, gap: 0 });
        const meta = [sp.schoolLabel, sp.castingTime, sp.range, sp.componentsLabel + (sp.components.materials ? ` (${sp.components.materials})` : ""), sp.durationFull]
          .filter(Boolean).join(" · ");
        para(meta, { size: 7.5, font: fonts.italic, color: style.muted, gap: 1 });
        const extra = [sp.toHit ? `${L.attack ?? "Angriff"} ${sp.toHit}` : "", sp.save ? `${L.save ?? "RW"} ${sp.save.abilityAbbr} ${L.dc ?? "SG"} ${sp.save.dc ?? ""}` : "", sp.damageLabel]
          .filter(Boolean).join(" · ");
        if (extra) para(extra, { size: 7.5, font: fonts.bold, color: style.ink, gap: 1 });
        if (sp.description) para(sp.description, { size: 8, gap: 5 });
      }
    }
  }
}

function hex(h) {
  const v = h.replace("#", "");
  return rgb(parseInt(v.slice(0, 2), 16) / 255, parseInt(v.slice(2, 4), 16) / 255, parseInt(v.slice(4, 6), 16) / 255);
}
