// Built-in templates. Paths are relative to the module root.
// All Heldenbogen variants share the same 1102 field names, so they use one mapping; `style` sets the
// colours of the appendix pages to match the variant (dark variants get dark appendix pages).
// `external: true` templates are third-party PDFs that are NOT shipped (copyright): the mapping ships,
// the PDF path comes from the module setting named in `setting`. `file` is the local dev copy in templates/.

const DARK = { paper: "#241c17", ink: "#efe5cf", muted: "#bcab88", accent: "#ecd398", rule: "#6b5636" };
const DAY = { paper: "#faf5ed", ink: "#1f1914", muted: "#5a4a37", accent: "#4a330f", rule: "#c9b48a" };
const HB = { mapping: "mappings/heldenbogen.mapping.json", lang: "de" };

export const BUILTIN_TEMPLATES = [
  {
    id: "heldenbogen-feldbuch", label: "PNPSP.Template.Feldbuch", file: "templates/heldenbogen-feldbuch.pdf", ...HB,
    style: { paper: "#e7dcc6", ink: "#1d1814", muted: "#4b4138", accent: "#5a1414", rule: "#b9a98a" },
  },
  {
    id: "heldenbogen-feldbuch-druck", label: "PNPSP.Template.FeldbuchDruck", file: "templates/heldenbogen-feldbuch-druck.pdf", ...HB,
    style: { paper: "#ffffff", ink: "#1d1814", muted: "#4b4138", accent: "#5a1414", rule: "#b9a98a" },
  },
  {
    id: "heldenbogen-codex", label: "PNPSP.Template.Codex", file: "templates/heldenbogen-codex.pdf", ...HB,
    style: { paper: "#29211b", ink: "#eadfc6", muted: "#b8a682", accent: "#e9cf8f", rule: "#6b5636" },
  },
  {
    id: "heldenbogen-codex-druck", label: "PNPSP.Template.CodexDruck", file: "templates/heldenbogen-codex-druck.pdf", ...HB,
    style: { paper: "#faf7f1", ink: "#1d1813", muted: "#5a4b38", accent: "#6e531f", rule: "#c9b48a" },
  },
  { id: "heldenbogen-tablet-tag", label: "PNPSP.Template.TabletTag", file: "templates/heldenbogen-tablet-tag.pdf", ...HB, style: DAY },
  { id: "heldenbogen-tablet-nacht", label: "PNPSP.Template.TabletNacht", file: "templates/heldenbogen-tablet-nacht.pdf", ...HB, style: DARK },
  {
    id: "heldenbogen-handy-tag", label: "PNPSP.Template.HandyTag", file: "templates/heldenbogen-handy-tag.pdf", ...HB,
    style: { ...DAY, paper: "#efe7d5" },
  },
  { id: "heldenbogen-handy-nacht", label: "PNPSP.Template.HandyNacht", file: "templates/heldenbogen-handy-nacht.pdf", ...HB, style: DARK },
  { id: "heldenbogen", label: "PNPSP.Template.Heldenbogen", file: "templates/heldenbogen-5e.pdf", ...HB },
  {
    id: "heldenbogen-druck", label: "PNPSP.Template.HeldenbogenDruck", file: "templates/heldenbogen-5e-druck.pdf", ...HB,
    style: { paper: "#ffffff" },
  },
  {
    // D&D 5e Charakterbogen v2.8.2 by André Tändler – shipped with the publisher's permission.
    id: "ataendler",
    label: "PNPSP.Template.Ataendler",
    file: "templates/ataendler-de.pdf",
    mapping: "mappings/ataendler.mapping.json",
    lang: "de",
  },
  {
    id: "official-de",
    label: "PNPSP.Template.OfficialDe",
    file: "official-de.pdf",
    external: true,
    setting: "officialDePdf",
    mapping: "mappings/official.mapping.json",
    lang: "de",
  },
  {
    id: "official-en",
    label: "PNPSP.Template.OfficialEn",
    file: "official-en.pdf",
    external: true,
    setting: "officialEnPdf",
    mapping: "mappings/official.mapping.json",
    lang: "en",
  },
];

/** Mapping adjusted for a template: its appendix colours and display name. */
export function mappingForTemplate(mapping, template, lang = template.lang) {
  return {
    ...mapping,
    lang,
    name: template.name ?? mapping.name,
    style: { ...(mapping.style ?? {}), ...(template.style ?? {}) },
  };
}
