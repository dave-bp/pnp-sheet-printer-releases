// Module settings.
import { BUILTIN_TEMPLATES } from "./templates.mjs";

export const MODULE_ID = "pnp-sheet-printer";

export function getSetting(key) {
  return game.settings.get(MODULE_ID, key);
}

export function registerSettings() {
  const reg = (key, data) => game.settings.register(MODULE_ID, key, {
    name: `PNPSP.Settings.${key}.name`,
    hint: `PNPSP.Settings.${key}.hint`,
    scope: "client",
    config: true,
    ...data,
  });

  reg("defaultTemplate", {
    type: String,
    default: "heldenbogen",
    choices: Object.fromEntries([...BUILTIN_TEMPLATES.map((t) => [t.id, t.label]), ["custom", "PNPSP.Template.Custom"]]),
  });
  reg("flatten", { type: Boolean, default: false });
  reg("spellCompendium", {
    type: String,
    default: "prepared",
    choices: {
      none: "PNPSP.SpellCompendium.none",
      prepared: "PNPSP.SpellCompendium.prepared",
      all: "PNPSP.SpellCompendium.all",
    },
  });
  reg("includePortrait", { type: Boolean, default: true });
  reg("metric", {
    type: String,
    default: "auto",
    choices: { auto: "PNPSP.Metric.auto", metric: "PNPSP.Metric.metric", imperial: "PNPSP.Metric.imperial" },
  });
  // Folder with the official sheets (official-de.pdf / official-en.pdf), not shipped for copyright reasons.
  reg("officialTemplateDir", { type: String, default: "", filePicker: "folder" });
  // User-supplied template (PDF + mapping JSON), selectable with the file picker.
  reg("customLabel", { type: String, default: "" });
  reg("customTemplate", { type: String, default: "", filePicker: "any" });
  reg("customMapping", { type: String, default: "", filePicker: "any" });
  reg("customLang", { type: String, default: "de", choices: { de: "Deutsch", en: "English" } });
}
