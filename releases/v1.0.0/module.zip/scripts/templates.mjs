// Built-in templates. Paths are relative to the module root.
// `external: true` templates are third-party PDFs that are NOT shipped (copyright): the mapping ships,
// the PDF is loaded from the folder set in the "officialTemplateDir" setting (file name = `file`).
// A user-supplied template (PDF + mapping JSON) can be added via the module settings.

export const BUILTIN_TEMPLATES = [
  {
    id: "heldenbogen",
    label: "PNPSP.Template.Heldenbogen",
    file: "templates/heldenbogen-5e.pdf",
    mapping: "mappings/heldenbogen.mapping.json",
    lang: "de",
  },
  {
    id: "heldenbogen-druck",
    label: "PNPSP.Template.HeldenbogenDruck",
    file: "templates/heldenbogen-5e-druck.pdf",
    mapping: "mappings/heldenbogen.mapping.json",
    lang: "de",
  },
  {
    id: "official-de",
    label: "PNPSP.Template.OfficialDe",
    file: "official-de.pdf",
    external: true,
    mapping: "mappings/official.mapping.json",
    lang: "de",
  },
  {
    id: "official-en",
    label: "PNPSP.Template.OfficialEn",
    file: "official-en.pdf",
    external: true,
    mapping: "mappings/official.mapping.json",
    lang: "en",
  },
];
