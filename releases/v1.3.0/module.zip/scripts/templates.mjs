// Built-in templates. Paths are relative to the module root.
// All Heldenbogen variants share the same 1102 field names, so they use one mapping; `style` sets the
// colours of the appendix pages to match the variant (dark variants get dark appendix pages).
// `external: true` templates are third-party PDFs that are NOT shipped (copyright): the mapping ships,
// the PDF path comes from the module setting named in `setting`. `file` is the local dev copy in templates/.

const DARK = { paper: "#241c17", ink: "#efe5cf", muted: "#bcab88", accent: "#ecd398", rule: "#6b5636" };
const DAY = { paper: "#faf5ed", ink: "#1f1914", muted: "#5a4a37", accent: "#4a330f", rule: "#c9b48a" };
const HB = { mapping: "mappings/heldenbogen.mapping.json", lang: "de" };
const st = (paper, ink, muted, accent, rule = "#c9c2b6") => ({ paper, ink, muted, accent, rule });

// Heldenbogen v3 class sheets: own design per class, pre-filled with class knowledge (saves, proficiencies,
// resource names). keepPresets: those texts stay where the character provides nothing (see pdf-engine).
const CLASS_SHEETS = [
  ["barbarian", "barbar", "Barbar", st("#f0e5d5", "#1e1914", "#5b4a3a", "#8e1b12")],
  ["bard", "barde", "Barde", st("#f8f3f6", "#221a28", "#5d4b68", "#6b2a6e")],
  ["druid", "druide", "Druide", st("#eceddd", "#1b2116", "#4d5a3e", "#3e6b2a")],
  ["warlock", "hexenmeister", "Hexenmeister", st("#e2dde3", "#17141c", "#4e4860", "#5a2a8a")],
  ["fighter", "kaempfer", "Kaempfer", st("#deddd9", "#16181a", "#4a4f55", "#8b1e1e")],
  ["cleric", "kleriker", "Kleriker", st("#faf7f2", "#1c1a14", "#5a5340", "#1f3c78")],
  ["wizard", "magier", "Magier", st("#eeebe5", "#161a26", "#4a5068", "#23367a")],
  ["artificer", "magieschmied", "Magieschmied", st("#f7f9fb", "#0f2236", "#3c5670", "#b0582a")],
  ["monk", "moench", "Moench", st("#f2eee3", "#141414", "#4b4740", "#b8321e")],
  ["paladin", "paladin", "Paladin", st("#f7f5f0", "#171a22", "#4a4f63", "#1d3a7a")],
  ["rogue", "schurke", "Schurke", st("#d7d6d2", "#121314", "#474a4f", "#7d1f1f")],
  ["ranger", "waldlaeufer", "Waldlaeufer", st("#f3ead6", "#1f1c14", "#5a5038", "#2f5a32")],
  ["sorcerer", "zauberer", "Zauberer", st("#f7ece1", "#23140e", "#6a4636", "#b0301c")],
];

export const BUILTIN_TEMPLATES = [
  // ---- Heldenbogen v3 ----
  { id: "heldenbogen-klar", group: "v3", label: "PNPSP.Template.Klar", file: "templates/heldenbogen-klar.pdf", ...HB,
    style: st("#fbfbfa", "#161616", "#6e6e6e", "#0e5a6b") },
  { id: "heldenbogen-erste-schritte", group: "v3", label: "PNPSP.Template.ErsteSchritte", file: "templates/heldenbogen-erste-schritte.pdf", ...HB,
    style: st("#ffffff", "#23201c", "#5f574d", "#b7791f") },
  { id: "heldenbogen-tiefwasser", group: "v3", label: "PNPSP.Template.Tiefwasser", file: "templates/heldenbogen-tiefwasser.pdf", ...HB,
    style: st("#fdfcfb", "#1d3557", "#4a5263", "#9b2d20") },
  { id: "heldenbogen-undermountain", group: "v3", label: "PNPSP.Template.Undermountain", file: "templates/heldenbogen-undermountain.pdf", ...HB,
    style: st("#312f38", "#ebe6f3", "#aaa2be", "#b48cff", "#5a5470") },
  // ---- class sheets: automatic choice by the character's main class, then each class ----
  {
    id: "heldenbogen-klasse-auto", group: "class", label: "PNPSP.Template.KlasseAuto", ...HB, keepPresets: true,
    classAuto: Object.fromEntries(CLASS_SHEETS.map(([cls, slug]) => [cls, `heldenbogen-klasse-${slug}`])),
    classFallback: "heldenbogen-klar",
  },
  ...CLASS_SHEETS.map(([cls, slug, key, style]) => ({
    id: `heldenbogen-klasse-${slug}`, group: "class", label: `PNPSP.Template.Klasse.${key}`,
    file: `templates/heldenbogen-klasse-${slug}.pdf`, ...HB, style, keepPresets: true, presetClass: cls,
  })),
  // ---- Heldenbogen v2 ----
  {
    group: "v2", id: "heldenbogen-feldbuch", label: "PNPSP.Template.Feldbuch", file: "templates/heldenbogen-feldbuch.pdf", ...HB,
    style: { paper: "#e7dcc6", ink: "#1d1814", muted: "#4b4138", accent: "#5a1414", rule: "#b9a98a" },
  },
  {
    group: "v2", id: "heldenbogen-feldbuch-druck", label: "PNPSP.Template.FeldbuchDruck", file: "templates/heldenbogen-feldbuch-druck.pdf", ...HB,
    style: { paper: "#ffffff", ink: "#1d1814", muted: "#4b4138", accent: "#5a1414", rule: "#b9a98a" },
  },
  {
    group: "v2", id: "heldenbogen-codex", label: "PNPSP.Template.Codex", file: "templates/heldenbogen-codex.pdf", ...HB,
    style: { paper: "#29211b", ink: "#eadfc6", muted: "#b8a682", accent: "#e9cf8f", rule: "#6b5636" },
  },
  {
    group: "v2", id: "heldenbogen-codex-druck", label: "PNPSP.Template.CodexDruck", file: "templates/heldenbogen-codex-druck.pdf", ...HB,
    style: { paper: "#faf7f1", ink: "#1d1813", muted: "#5a4b38", accent: "#6e531f", rule: "#c9b48a" },
  },
  { group: "v2", id: "heldenbogen-tablet-tag", label: "PNPSP.Template.TabletTag", file: "templates/heldenbogen-tablet-tag.pdf", ...HB, style: DAY },
  { group: "v2", id: "heldenbogen-tablet-nacht", label: "PNPSP.Template.TabletNacht", file: "templates/heldenbogen-tablet-nacht.pdf", ...HB, style: DARK },
  {
    group: "v2", id: "heldenbogen-handy-tag", label: "PNPSP.Template.HandyTag", file: "templates/heldenbogen-handy-tag.pdf", ...HB,
    style: { ...DAY, paper: "#efe7d5" },
  },
  { group: "v2", id: "heldenbogen-handy-nacht", label: "PNPSP.Template.HandyNacht", file: "templates/heldenbogen-handy-nacht.pdf", ...HB, style: DARK },
  { group: "v1", id: "heldenbogen", label: "PNPSP.Template.Heldenbogen", file: "templates/heldenbogen-5e.pdf", ...HB },
  {
    group: "v1", id: "heldenbogen-druck", label: "PNPSP.Template.HeldenbogenDruck", file: "templates/heldenbogen-5e-druck.pdf", ...HB,
    style: { paper: "#ffffff" },
  },
  {
    // D&D 5e Charakterbogen v2.8.2 by André Tändler – shipped with the publisher's permission.
    group: "other",
    id: "ataendler",
    label: "PNPSP.Template.Ataendler",
    file: "templates/ataendler-de.pdf",
    mapping: "mappings/ataendler.mapping.json",
    lang: "de",
  },
  {
    group: "other",
    id: "official-de",
    label: "PNPSP.Template.OfficialDe",
    file: "official-de.pdf",
    external: true,
    setting: "officialDePdf",
    mapping: "mappings/official.mapping.json",
    lang: "de",
  },
  {
    group: "other",
    id: "official-en",
    label: "PNPSP.Template.OfficialEn",
    file: "official-en.pdf",
    external: true,
    setting: "officialEnPdf",
    mapping: "mappings/official.mapping.json",
    lang: "en",
  },
];

/** Mapping adjusted for a template: its appendix colours, display name and preset handling. */
export function mappingForTemplate(mapping, template, lang = template.lang) {
  return {
    ...mapping,
    lang,
    name: template.name ?? mapping.name,
    keepPresets: !!template.keepPresets,
    presetClass: template.presetClass ?? null,
    style: { ...(mapping.style ?? {}), ...(template.style ?? {}) },
  };
}

/**
 * Whether a template's presets (class knowledge) should stay: only for a character that actually has that class –
 * a fighter printed on the wizard sheet must not inherit "spellcasting class: wizard".
 */
export function presetsApply(mapping, model) {
  if (!mapping.keepPresets) return false;
  if (!mapping.presetClass) return true;
  return (model.identity?.classes ?? []).some((c) => c.identifier === mapping.presetClass);
}

/** Display groups of the print dialog, in order. */
export const TEMPLATE_GROUPS = ["v3", "class", "v2", "v1", "other"];

/** Resolve the automatic class sheet for a character model (main class = first, i.e. original/highest class). */
export function resolveClassTemplate(template, model, templates = BUILTIN_TEMPLATES) {
  if (!template.classAuto) return template;
  const ident = model.identity?.classes?.[0]?.identifier;
  const id = template.classAuto[ident] ?? template.classFallback;
  return templates.find((t) => t.id === id) ?? template;
}
