// Resolvers for the "ataendler" character sheet (D&D 5e Charakterbogen v2.8.2, André Tändler).
// That sheet carries its own JavaScript: format scripts prepend "+" to positive numbers, calculation
// scripts derive modifiers, saves, skills, part weights (lb), total load and jump distances.
// These resolvers therefore return { display, raw }: raw is what the sheet's scripts expect in /V
// ("2", "1.5"), display is what is drawn ("+2", "1,50"). Values follow the sheet's own formulas so a
// recalculation in Acrobat yields the same numbers.

import { signed, num, joinNonEmpty } from "../model/text.mjs";
import { terms } from "../model/terms.mjs";

const ATTR = { str: "Stä", dex: "Ges", con: "Kon", int: "Int", wis: "Wei", cha: "Cha" };
// SizeCat dropdown: display label -> export value (capacity multiplier) as defined in the PDF
const SIZE = { tiny: ["Winzig", "0.5"], sm: ["Klein", "0.5"], med: ["Mittelgroß", "1"], lg: ["Groß", "2"], huge: ["Riesig", "4"], grg: ["Gigantisch", "8"] };
const INVENTORY_ROWS = 55;
const PART_RANGES = [[1, 14], [15, 28], [29, 41], [42, 55]];

/** Number stored raw, shown with sign (the sheet's format script adds "+" itself). */
const plus = (n) => (n === null || n === undefined || n === "" ? "" : { display: signed(n), raw: String(Number(n)) });
/** Unit weight of an inventory entry in lb (dnd5e stores lb unless the world uses metric units). */
const lb = (item) => (item.weightUnits === "kg" ? item.weight * 2 : item.weight) || 0;
const fixed2 = (n) => Number(n).toFixed(2);

function inventoryRows(m) {
  return m.equipment.items.slice(0, INVENTORY_ROWS);
}
function partWeight(m, part) {
  const [from, to] = PART_RANGES[part - 1];
  return inventoryRows(m).slice(from - 1, to).reduce((s, i) => s + i.quantity * lb(i), 0);
}
function sizeMultiplier(m) {
  return Number((SIZE[m.identity.sizeKey] ?? SIZE.med)[1]);
}

export const ATAENDLER_RESOLVERS = {
  ataProfBonus: (m) => plus(m.combat.prof),
  ataAbilityMod: (m, k) => plus(m.abilities[k]?.mod),
  ataSave: (m, k) => plus(m.abilities[k]?.save),
  ataSkill: (m, k) => plus(m.skills[k]?.total),
  /** "Alleskönner" (Jack of All Trades): any skill with half proficiency. */
  ataJackOfAllTrades: (m) => Object.values(m.skills).some((s) => s.prof === 0.5),
  ataPassive: (m) => String(m.skills.prc.passive),
  ataSizeCat: (m) => {
    const [label, raw] = SIZE[m.identity.sizeKey] ?? [];
    return label ? { display: label, raw } : "";
  },
  /** Body weight: the sheet appends " lb" itself, so store the number in lb. */
  ataBodyWeight: (m) => {
    const t = String(m.persona.weight ?? "").trim();
    const match = t.match(/^(\d+(?:[.,]\d+)?)\s*(kg|lb|lbs|pfd\.?|pfund)?$/i);
    if (!match) return t;
    let v = Number(match[1].replace(",", "."));
    if (/kg/i.test(match[2] ?? "")) v = Math.round(v * 2 * 10) / 10;
    return { display: `${num(v, "de")} lb`, raw: String(v) };
  },
  ataPartWeight: (m, part) => {
    const w = partWeight(m, part);
    return w ? { display: String(Math.round(w * 100) / 100), raw: String(Math.round(w * 100) / 100) } : "";
  },
  /** Total load as the sheet computes it: part weights + coins (50 per lb), "12.34 lb". */
  ataTotalLoad: (m) => {
    const c = m.equipment.currency;
    const coins = (c.pp + c.gp + c.ep + c.sp + c.cp) / 50;
    const total = [1, 2, 3, 4].reduce((s, p) => s + partWeight(m, p), 0) + coins;
    return total ? `${fixed2(total)} lb` : "";
  },
  ataEncumbered: (m) => {
    const s = m.abilities.str.score; const k = sizeMultiplier(m);
    return `${s * 5 * k + 1} - ${s * 10 * k} lb`;
  },
  ataHeavilyEncumbered: (m) => {
    const s = m.abilities.str.score; const k = sizeMultiplier(m);
    return `${s * 10 * k + 1} - ${s * 15 * k} lb`;
  },
  ataMaxLift: (m) => `${m.abilities.str.score * 30 * sizeMultiplier(m)} lb`,
  /** Jump distances in metres, formulas from the sheet (raw "0.45", shown "0.45 m"). */
  ataJump: (m, kind) => {
    const s = m.abilities.str.score; const mod = m.abilities.str.mod;
    const v = { highStanding: ((mod + 3) * 0.3) / 2, highRunning: (mod + 3) * 0.3, longStanding: (s * 0.3) / 2, longRunning: s * 0.3 }[kind];
    return v > 0 ? { display: `${fixed2(v)} m`, raw: fixed2(v) } : "";
  },
  ataSensesBlock: (m) => joinNonEmpty([
    m.sensesLabel,
    m.defenses.resistances.length ? `Resistenz: ${m.defenses.resistances.join(", ")}` : "",
    m.defenses.immunities.length ? `Immunität: ${m.defenses.immunities.join(", ")}` : "",
    m.defenses.vulnerabilities.length ? `Anfälligkeit: ${m.defenses.vulnerabilities.join(", ")}` : "",
    m.defenses.conditionImmunities.length ? `Zustandsimmun: ${m.defenses.conditionImmunities.join(", ")}` : "",
    `Passive Wahrnehmung ${m.combat.passive.prc}, Motiv erkennen ${m.combat.passive.ins}, Nachforschungen ${m.combat.passive.inv}`,
  ], "\n"),
  ataLanguage: (m, i) => m.proficiencies.languages[i - 1] ?? "",
  ataTool: (m, i) => {
    const t = m.proficiencies.tools[i - 1];
    return t ? (t.prof >= 2 ? `${t.label} (Exp.)` : t.label) : "";
  },
  /** Spell slots: regular slots plus pact slots of the same level (the sheet has no pact box). */
  ataSlotTotal: (m, lvl) => {
    const s = m.spellcasting.slots.find((x) => x.level === lvl);
    const p = m.spellcasting.pact?.level === lvl ? m.spellcasting.pact : null;
    const total = (s?.max ?? 0) + (p?.max ?? 0);
    return total ? String(total) : "";
  },
  ataSlotUsed: (m, lvl) => {
    const s = m.spellcasting.slots.find((x) => x.level === lvl);
    const p = m.spellcasting.pact?.level === lvl ? m.spellcasting.pact : null;
    const used = (s ? s.max - s.value : 0) + (p ? p.max - p.value : 0);
    return used ? String(used) : "";
  },
};

export const ATAENDLER_LIST_RESOLVERS = {
  ataAttacks: (m) => m.attacks.map((a) => {
    return {
      name: a.name,
      prof: !!a.proficient,
      attr: ATTR[a.ability] ?? "",
      range: a.range,
      // Numeric to-hit goes into the narrow bonus box; save DCs ("SG 15 GES") go into the description.
      bonus: /^[+-]?\d+$/.test(a.toHit) ? plus(Number(a.toHit)) : "",
      damage: a.damage.map((d) => d.formula).join(" + ") || "",
      damageType: [...new Set(a.damage.map((d) => d.type).filter(Boolean).map((t) => terms("de").damageTypes[t] ?? t))].join(", "),
      description: joinNonEmpty([/^[+-]?\d+$/.test(a.toHit) ? "" : a.toHit, a.notes], " · "),
    };
  }),
  ataInventory: (m) => inventoryRows(m).concat(m.equipment.items.slice(INVENTORY_ROWS)).map((i) => ({
    name: `${i.depth ? "› ".repeat(i.depth) : ""}${i.name}${i.attuned ? " (E)" : ""}`,
    qty: String(i.quantity),
    weight: lb(i) ? { display: num(lb(i), "de", 2), raw: String(Math.round(lb(i) * 100) / 100) } : "",
  })),
};
