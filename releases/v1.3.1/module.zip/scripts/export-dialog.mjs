// Export dialog (ApplicationV2): choose template and options, then export.

import { MODULE_ID, getSetting } from "./settings.mjs";
import { availableTemplates, exportActor } from "./exporter.mjs";
import { TEMPLATE_GROUPS } from "./templates.mjs";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

export class SheetExportDialog extends HandlebarsApplicationMixin(ApplicationV2) {
  /** @param {Actor} actor */
  constructor(actor, options = {}) {
    super({ ...options, id: `${MODULE_ID}-export-${actor.id}` });
    this.actor = actor;
  }

  static DEFAULT_OPTIONS = {
    tag: "form",
    classes: ["pnpsp-export-dialog"],
    window: {
      title: "PNPSP.Dialog.Title",
      icon: "fa-solid fa-print",
      contentClasses: ["standard-form"],
    },
    position: { width: 480 },
    form: {
      handler: SheetExportDialog.#onSubmit,
      submitOnChange: false,
      closeOnSubmit: true,
    },
  };

  static PARTS = {
    form: { template: `modules/${MODULE_ID}/hbs/export-dialog.hbs` },
    footer: { template: "templates/generic/form-footer.hbs" },
  };

  get title() {
    return `${game.i18n.localize("PNPSP.Dialog.Title")}: ${this.actor.name}`;
  }

  /** @override */
  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    const current = getSetting("defaultTemplate");
    const templates = availableTemplates();
    return {
      ...context,
      actorName: this.actor.name,
      groups: TEMPLATE_GROUPS.map((g) => ({
        label: game.i18n.localize(`PNPSP.Group.${g}`),
        templates: templates.filter((t) => (t.group ?? "other") === g)
          .map((t) => ({ id: t.id, label: t.label, selected: t.id === current })),
      })).filter((g) => g.templates.length),
      langs: [
        { value: "auto", label: game.i18n.localize("PNPSP.Dialog.LangAuto"), selected: true },
        { value: "de", label: "Deutsch" },
        { value: "en", label: "English" },
      ],
      spellModes: ["none", "prepared", "all"].map((v) => ({
        value: v, label: game.i18n.localize(`PNPSP.SpellCompendium.${v}`), selected: v === getSetting("spellCompendium"),
      })),
      flatten: getSetting("flatten"),
      includePortrait: getSetting("includePortrait"),
      buttons: [
        { type: "submit", icon: "fa-solid fa-file-pdf", label: "PNPSP.Dialog.Export" },
      ],
    };
  }

  /**
   * @this {SheetExportDialog}
   * @param {SubmitEvent} event
   * @param {HTMLFormElement} form
   * @param {FormDataExtended} formData
   */
  static async #onSubmit(event, form, formData) {
    const data = formData.object;
    const notice = ui.notifications.info(game.i18n.format("PNPSP.Notify.Working", { name: this.actor.name }), { permanent: true });
    try {
      const { filename, report } = await exportActor(this.actor, {
        templateId: data.template,
        lang: data.lang,
        flatten: !!data.flatten,
        spellCompendium: data.spellCompendium,
        portrait: !!data.includePortrait,
      });
      const extra = report.appendix.length ? game.i18n.localize("PNPSP.Notify.Appendix") : "";
      ui.notifications.info(`${game.i18n.format("PNPSP.Notify.Done", { file: filename })} ${extra}`.trim());
    } catch (err) {
      console.error(`${MODULE_ID} | export failed`, err);
      ui.notifications.error(game.i18n.format("PNPSP.Notify.Failed", { error: err.message ?? String(err) }));
    } finally {
      ui.notifications.remove?.(notice);
    }
  }
}
